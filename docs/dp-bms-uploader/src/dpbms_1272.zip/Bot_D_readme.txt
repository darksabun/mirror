Bogus of true
Made by 0samil0 (twitter @0samil0)

Level : ��10?
Notes : 2057
Total : 500

Thanks to polysha for permission! (twitter @polytarou)
Special thanks : key (twitter @keyiidxdp)
		 ddobic (twitter @double_D_biku)

Feel free to contact me for some feedback!