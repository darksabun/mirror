本体URL
https://pupuly.nekokan.dyndns.info/bms/v/157

stagefileとbannerを勝手に追加してます
SPNとズレ抜けなし