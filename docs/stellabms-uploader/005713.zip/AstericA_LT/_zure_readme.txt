Based on the `_raw_bms` file, the `0I` keysound object at position #041 01 (15/16) has been moved to #042 01 (0/1).
`_raw_bms` ファイルに基づき、#041 01（15/16）の位置にあった `0I` オブジェクトを、#042 01（0/1）に移動しました。