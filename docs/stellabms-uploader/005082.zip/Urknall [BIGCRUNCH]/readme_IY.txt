Urknall [BIGCRUNCH]

BPM:145 推定難易度:st12 NOTES:3538 TOTAL:956

手動ディレイによるキー音の追加あり

同梱譜面(_NORMAL.bms)と比較してズレ抜け無し

本体URL
　→https://manbow.nothing.sh/event/event.cgi?action=More_def&num=90&event=132