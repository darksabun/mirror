[本体URL]
https://manbow.nothing.sh/event/event.cgi?action=More_def&num=405&event=137

[ズレ抜け]
未配置ファイルをベースに作成
同梱_N.bmsとズレ抜けなし（空文字列のStagefile定義のみ）