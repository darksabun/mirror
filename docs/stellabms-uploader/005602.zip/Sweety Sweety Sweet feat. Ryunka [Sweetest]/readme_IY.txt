Sweety Sweety Sweet feat. Ryunka [Sweetest]

BPM:133 推定難易度:st6 NOTES:3461 TOTAL:693

意図的なキー音の追加や削除を含むアレンジ差分の為ズレ抜けチェック不可

本体URL
　→https://drive.google.com/file/d/1-eLZEs9oz0dXR0j0k3qo9GVl6-RZQZ_R/view?usp=drive_link