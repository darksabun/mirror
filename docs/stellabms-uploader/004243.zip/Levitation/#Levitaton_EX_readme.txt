★22? Levitation [EX]

Notes : 2300 / Total : 500
180BPMの物量譜面

*** 導入について ***
他差分の追加音源を使用しているため、
必ず以下のリンクからLevitation [乱打ONLY]を一緒に導入してください。
https://bms.parksulab.xyz/chart/sabun7.html
(И11にあります)

*** ズレ抜けについて ***
ParksuさんのLevitation [乱打ONLY]に同梱されている0note譜面(Levitation_0note.xxx)から作成。
0note譜面とのズレは全て意図的なものです。
また、追加音源がある差分のため同梱とはズレチェックができません。
