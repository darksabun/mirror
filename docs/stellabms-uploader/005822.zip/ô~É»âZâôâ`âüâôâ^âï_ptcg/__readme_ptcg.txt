(st5?)
冬星センチメンタル [微縦ガチフィジカル]

本体URL:
https://k-bms.com/party_pabat/party.jsp?board_num=20&num=3&order=reg&odtype=a

ズレ抜けについて
	キー音追加及び少しのアレンジを加えているためズレチェック不可
	同梱[ANOTHER](4_another.bms)とbms diff toolで比較して検出されるズレ抜けは全て意図的なものです