2分以上のwav定義があったので、音切りしています。
本ファイルのoggファイルを、楽曲フォルダに入れてください。
意図したdiffがあります。

There was a wav definition that was over 2 minutes long, so it has been sound cut.
Please put the ogg file of this file in the music folder.
There is an intended diff.

translated by deepl