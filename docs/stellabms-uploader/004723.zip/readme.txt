本体:https://manbow.nothing.sh/event/event.cgi?action=More_def&num=413&event=146
同梱Anotherと比較してズレ抜け無し