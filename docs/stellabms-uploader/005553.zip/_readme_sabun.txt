†#μИcl&.-(1Д9 → [V]Д|2`/†#&|2
Micelle / obj: Mary_Sue

本体：https://ux.getuploader.com/jubeanaly/download/45/[Micelle]Thunderclap_ogg.zip
推定レベル：★23-24

キー音切りのせいでずれ抜けあり。
よろしくお願いいたします。

Mary_Sue (https://darksabun.github.io/Mary_Sue/ or @MarySue_BMS)
2025/05/09