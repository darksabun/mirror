Energetic [!И73N5E]

BPM:200 推定難易度:st6 NOTES:3822 TOTAL:727

同梱譜面(_NORMAL7.bms)と比較してズレ抜け無し

本体URL
　→https://9domu46i.com/yuruyuru/phase12.html