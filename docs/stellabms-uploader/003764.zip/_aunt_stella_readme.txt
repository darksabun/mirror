st11? 〇、[永世。]
st2? 〇、[久遠。]

Kolaa & 熊子 (movie: 毛腿猪兔子 & Kolaa) obj:Stellaおばさん

ディレイ追加のためズレチェック不可。

本体URL
https://manbow.nothing.sh/event/event.cgi?action=More_def&num=296&event=142
