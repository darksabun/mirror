From Highest HEAVEN [Ain't too proud to rely on!]

BPM:146 推定難易度:st7 NOTES:3000 TOTAL:600

手動ディレイによるキー音の追加あり

同梱譜面(iROH_From_Highest_HEAVEN_L.bme)と比較して追加したキー音以外のズレ抜け無し

本体URL
　→http://uploader.bms.ms/data/iroh_from_highest_heaven.zip