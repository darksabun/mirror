URL: https://manbow.nothing.sh/event/event.cgi?action=More_def&num=42&event=149
Difficulty: sl1

BOF:21差分企画: https://darksabun.github.io/event/bof21/