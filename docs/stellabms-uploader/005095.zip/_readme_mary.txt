私食べごろよ
DJ DAEK / obj: Mary_Sue

推定レベル：★23
本体：https://drive.google.com/file/d/1C8xpg8ci9gZhyMG0B0M2hTHgHRIXNYX7/view?usp=drive_link

_me.bms基準ズレ抜けなし。
よろしくお願いいたします。

Mary_Sue (https://darksabun.github.io/Mary_Sue/ or @MarySue_BMS)
2025/02/15