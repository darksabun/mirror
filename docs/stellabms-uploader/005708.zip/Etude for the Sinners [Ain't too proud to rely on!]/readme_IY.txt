Etude for the Sinners [Ain't too proud to rely on!]

BPM:200 推定難易度: NOTES:3160 TOTAL:632

キー音の追加あり

BMS Diff Toolで同梱譜面(Etude_HYPER.bms)と比較して検出されるズレは意図的なものです(同梱譜面が配置ミスしてそうだったので勝手に修正)

本体URL
　→https://manbow.nothing.sh/event/event.cgi?action=More_def&num=461&event=88