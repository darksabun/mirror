Live My Life With [Ain't too proud to rely on!]

BPM:170 乱打 推定難易度:st2 NOTES:2904 TOTAL:534

同梱譜面(0.Live_My_Life_With_N.bms)と比較してズレ抜け無し

本体URL
　→http://manbow.nothing.sh/event/event.cgi?action=More_def&num=401&event=123