Stella Story -for Stella Warriors-

BPM:152 推定難易度:st11 NOTES:3204 TOTAL:769

手動ディレイなどの意図的なキー音の追加があります

同梱譜面(stella_story_7a.bms)と比較して追加したキー音意外のズレ抜け無し

本体URL
　→https://drive.google.com/file/d/1SuDVtZNb0o8WyFim2LtCfvq0mply8_ZY/view?usp=drive_link