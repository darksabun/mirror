βehexeη‐δ [PLAY MoRE]

BPM:198 乱打 ズレ 推定難易度:st6 NOTES:3120 TOTAL:569

追加キー音あり

同梱譜面(_bexehen_1n.bml)と比較して追加キー音以外のズレ抜け無し

本体URL
　→https://manbow.nothing.sh/event/event.cgi?action=More_def&num=464&event=140