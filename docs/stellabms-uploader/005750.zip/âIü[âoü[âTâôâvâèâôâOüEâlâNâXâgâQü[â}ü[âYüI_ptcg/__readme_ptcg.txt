(st6?)
オーバーサンプリング・ネクストゲーマーズ！ [Intense]

本体URL:
https://manbow.nothing.sh/event/event.cgi?action=More_def&num=9&event=148

ズレ抜けについて
	意図的なキー音の追加があります
	同梱[ANOTHER](Oversampling_A.bme)とbms diff toolで比較して、ズレ抜け無し