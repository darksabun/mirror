SYNTHETICS [F0R ABYSS] (fix)

BPM:160 推定難易度:st3 NOTES:2973 TOTAL:514

以前作った差分の修正版

同梱譜面(SYNTHETICS ANOTHER.bms)と比較してズレ抜け無し

本体URL
　→https://manbow.nothing.sh/event/event.cgi?action=More_def&num=285&event=123