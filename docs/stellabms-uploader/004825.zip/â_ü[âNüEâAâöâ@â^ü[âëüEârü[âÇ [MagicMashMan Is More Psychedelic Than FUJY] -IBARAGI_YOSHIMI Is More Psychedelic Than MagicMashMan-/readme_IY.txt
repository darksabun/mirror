ダーク・アヴァターラ・ビーム [MagicMashMan Is More Psychedelic Than FUJY] -IBARAGI_YOSHIMI Is More Psychedelic Than MagicMashMan-

BPM:160 乱打 微縦連 推定難易度:st7～8 NOTES:3557 TOTAL:677

手動ディレイによる追加キー音あり

同梱譜面と比較してノーツを削除したことによる意図的なズレ抜けがあります(最初と最後にあるZY,ZZ定義のノーツ)それ以外のズレ抜けはありません

本体URL
　→https://drive.google.com/file/d/16qNSvAkTFxilF_sKYhCTKol0G2EY8qK8/view?usp=drive_link