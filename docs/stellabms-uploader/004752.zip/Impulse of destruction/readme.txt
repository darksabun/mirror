本家URL

https://manbow.nothing.sh/event/event.cgi?action=More_def&num=89&event=132


sl10～sl11ぐらい?
sl帯ではあまりない6個押しを多く配置してslの難易度に収まるように調整しました
ANOTHER譜面とズレチェック済み