BMSをたくさん作るぜ'26 より
バベルの塔が崩れても / ROyama vs. 19xx(feat.羽累)
https://venue.bmssearch.net/bmstukuru2026/5

BPM180のいろいろな2連打複合です st5～6ぐらい？
前半クリアに影響しないレベルのLN複合があります

※ANOTHER譜面から作成しましたが、一部キー音を変更しています（アルペジオの24分→16分化、#61のキック追加）
