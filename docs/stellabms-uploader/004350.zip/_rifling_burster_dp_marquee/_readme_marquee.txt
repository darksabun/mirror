DP☆6/☆10/☆12(★3)/★10 Rifling Burster

BMS URL
https://manbow.nothing.sh/event/event.cgi?action=More_def&num=288&event=110

No Misalignment (Based on SPA.bms)