永夜ノ蝶 -LAST BOSS-

BPM:190 乱打 微縦連 ズレ 推定難易度:st9 NOTES:2804 TOTAL:614

同梱譜面(_Eiya_no_Cho_easy7.bme)と比較してズレ抜け無し

本体URL
　→https://manbow.nothing.sh/event/event.cgi?action=More_def&num=496&event=142