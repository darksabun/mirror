(st5?) フロンティア↑↑エクスプローラー [GOD]

本体URL:https://manbow.nothing.sh/event/event.cgi?action=More_def&num=87&event=132

ズレ抜けについて
	微アレンジによる意図的なキー音の追加があります。それ以外はズレ抜け無し。
	bms diff toolにて同梱[ANOTHER 7](_a.bms)と比較して、ズレ抜けがないことを確認しています。
