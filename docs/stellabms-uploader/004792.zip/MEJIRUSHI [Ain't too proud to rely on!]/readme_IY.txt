MEJIRUSHI [Ain't too proud to rely on!]

BPM:195 乱打 微縦連 推定難易度:st3 NOTES:2615 TOTAL:424

追加キー音あり

同梱譜面(MEJIRUSHI_NORMAL.bms)と比較して追加キー音以外のズレ抜け無し

本体URL
　→https://mega.nz/folder/BDJAhJDJ#BrSjRbk10U_uFphI7JG_xg/file/Ra4kgJKa