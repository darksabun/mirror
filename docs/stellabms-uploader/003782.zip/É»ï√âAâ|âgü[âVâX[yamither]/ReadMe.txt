

---------------------------------

星屑アポトーシス

[yamither] 縦6

---------------------------------

要素: 連打/微ギミック

=================================

Music: 椎名まゆり(Lime)
obj: くろ

Base BMS URL: https://manbow.nothing.sh/event/event.cgi?action=More_def&num=324&event=83

=================================
