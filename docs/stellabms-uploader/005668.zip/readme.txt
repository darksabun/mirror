[本体URL]
https://manbow.nothing.sh/event/event.cgi?action=More_def&num=498&event=133

[ズレ抜け]
未配置ファイルをベースに作成
同梱_sunset_toybox_7N.bmsとズレ抜けなし

[配置リファレンス]
Babel [ANOTHER] / Nizikawa feat. nayuta
EROICA / HERO
Rainbow after snow / 猫叉Master Feat.林ももこ
Yum Yum Jelly / YUC'e