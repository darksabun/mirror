Existence [Reach four the Stars]

BPM:150 推定難易度:st8 NOTES:3300 TOTAL:726

同梱譜面(existence_n.bms)と比較してズレ抜け無し

本体URL
　→https://manbow.nothing.sh/event/event.cgi?action=More_def&num=295&event=104