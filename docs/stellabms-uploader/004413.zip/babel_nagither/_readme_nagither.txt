(st1?) Babel [NAGITHER]

本体:https://manbow.nothing.sh/event/event.cgi?action=More_def&num=29&event=110

ズレ抜けについて
	意図的なキー音の追加があります
	同梱[ANOTHER](_another.bme)とbms diff toolで比較して、ズレ抜け無し