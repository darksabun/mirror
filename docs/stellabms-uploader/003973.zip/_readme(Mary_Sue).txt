【Freak《Show】Down》 「Gra〈Mary」ther〉
obj: Mary_Sue bms:暮狛 / mov:くわぎう

本体：https://ctconnected.net/bms
推定レベル：★25?

同梱0notesファイルの_base_.bxxx基準、ズレ抜けなし。
曲名とふさわしい差分名を付けたかったので、「Gramary」という珍しい単語まで探し当てました…
よろしくお願いいたします。

Mary_Sue (https://darksabun.github.io/Mary_Sue/ or @MarySue_BMS)
2024/05/17