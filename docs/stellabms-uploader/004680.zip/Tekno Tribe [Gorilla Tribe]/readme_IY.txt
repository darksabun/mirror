Tekno Tribe [Gorilla Tribe]

BPM190 乱打/体力　推定難易度:st6 NOTES:3843 TOTAL:695

無音ノーツを使っています

同梱譜面(teknotribe_spn.bms)と比較してズレ抜け無し

本体URL
　→https://event.yaruki0.net/VSevent/impression/58