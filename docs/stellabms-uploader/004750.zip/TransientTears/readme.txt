本家URL : https://manbow.nothing.sh/event/event.cgi?action=More_def&num=170&event=146

動作確認環境 : beatoraja

st1強～st2弱ぐらいの想定
本家SPHARD譜面とのズレ確認済み