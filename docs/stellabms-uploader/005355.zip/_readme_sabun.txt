Defeated Wings [MARYTHER]
ALTM / obj:Mary_Sue

推定レベル：★22
本体：http://www1.axfc.net/uploader/so/3035917.zip

_df_7normal.bme基準ずれ抜けなし。
よろしくお願いいたします。

Mary_Sue (https://darksabun.github.io/Mary_Sue/ or @MarySue_BMS)
2025/04/03