BIGBLUE
DJ ARASHI feat.Megpoid
obj:otenami

Link
https://drive.google.com/file/d/1QDwA4kxHcaMM-FfEyVkPV-zwPgS3cxGA/view?usp=drive_link

difficulty:sl6