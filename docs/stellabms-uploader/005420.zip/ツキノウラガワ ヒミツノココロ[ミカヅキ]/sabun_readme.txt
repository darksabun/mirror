本体URL:https://manbow.nothing.sh/event/event.cgi?action=More_def&num=467&event=140
同梱14_behind_the_moon_7extとズレなし

無音ノーツあり