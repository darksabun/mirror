https://manbow.nothing.sh/event/event.cgi?action=More_def&num=239&event=74

ps_hyper.bmeと比較してズレなし
