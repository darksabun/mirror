st0? ZETABYTE [EXABYTE]

Ras obj:E

後半曲改変のためズレチェック不可

本体URL
https://manbow.nothing.sh/event/event.cgi?action=More_def&num=355&event=142
