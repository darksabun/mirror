本家URL
https://drive.google.com/file/d/1VZUO3zqkTxJ2SHKJAj-wpf7o8R2ISq-x/view?usp=sharing
(自作差分投入済み）

想定難易度★23
notes : 3300
TOTAL値 : 660
ズレチェック : 本家Lunatic譜面

本家Lunatic譜面の弱体化版
計算上4-2発狂や3-3とほぼ同じ密度にしたのに全然押せなくてズレの難しさを実感しました。
発狂地帯だけ手心を加えたのでそれ以外はほぼLunatic譜面と同じです。つまり手抜き譜面