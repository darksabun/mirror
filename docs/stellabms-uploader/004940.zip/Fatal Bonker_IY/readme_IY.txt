Fatal Bonker [Critical] / [Fatality]

BPM:230 推定難易度:st6 / st10 NOTES:2918 /3670  TOTAL:615 / 740

キー音の追加あり

両差分共に同梱譜面(_spn.bms)と比較して追加したキー音以外のズレ抜け無し

本体URL
　→https://manbow.nothing.sh/event/event.cgi?action=More_def&num=468&event=142