EUROBEATアイドル橘花音のテーマ -uma Remix- [過労死]

BPM:132 推定難易度:st5 NOTES:3760 TOTAL:600

同梱譜面(_7a.bms)と比較してズレ抜け無し

本体URL
　→https://manbow.nothing.sh/event/event.cgi?action=More_def&event=123&num=272