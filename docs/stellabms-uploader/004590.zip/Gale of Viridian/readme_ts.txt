ディレイ配置+音源追加配置によるズレあり抜けなし
※どうしてもズレ配置にしたい部分があり、
ディレイにすると音の違和感が激しかったため音がない場所に無音ノーツを配置しています。
本体:https://manbow.nothing.sh/event/event.cgi?action=More_def&num=217&event=146