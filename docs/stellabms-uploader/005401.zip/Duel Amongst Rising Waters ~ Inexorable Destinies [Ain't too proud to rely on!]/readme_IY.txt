Duel Amongst Rising Waters ~ Inexorable Destinies [Ain't too proud to rely on!]

BPM:160 推定難易度:st4 NOTES:3064 TOTAL:644

同梱未配置(temp.bms)と比較してズレ抜け無し

本体URL
　→https://9domu46i.com/yuruyuru/phase15.html