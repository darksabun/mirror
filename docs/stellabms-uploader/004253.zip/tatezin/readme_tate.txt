★12/縦4? 路上のタテジン-Shou+rt Mix-
tarolabo vo：小宮真央 obj：E

★★2/縦7? 路上のタテジン-Shou+rt Mix- [全認識]
tarolabo vo：小宮真央 obj：日本縦連打連合会

marie氏の追加音源を使用しています。
以下URLからDLしてください。
https://www.dropbox.com/s/teidgnshu9ps019/sarazin_hq.zip?dl=0

本体URL
http://ofuton.tk/tarolabo/girizin.rar
