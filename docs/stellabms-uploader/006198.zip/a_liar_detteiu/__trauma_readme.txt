今回の譜面作成を行ううえで、下記の小節にて該当の譜面の一部を使用しております。
再現するうえで、無音ノーツを大量に配置しています。極力演奏感が損なわれないよう譜面を構成していますが、違和感が凄いと思うので許容できる方は是非プレイしてみてください。

#007～#008：sl5 squartatrice [HARD]
#010～#013：sl0 BLAZE YOUR SOUL [SP ANOTHER]
#015～#017：sl1 Brave My Soul -Flareness Heart-
#022～#023：sl3 Re/Im [ZOI]
#024～#025：sl7 Ground Z.E.R.O. [ZOI]
#028～#030：sl3 Disorder -ANOTHER-
#034～#035：sl6 白菊 [Snother]
#036～#039：sl7 energy night [JOY]
#044～#047：sl9 DESPERATE -Last Battle-
#059～#062：sl9 ニニ - ニサシゴ -
#063～#066：sl10 Andromeda [yumether]
#067～#070：sl12 ヒメタイプ [LAPITHER]
#071～#074：sl12 Terpsichore [Li]
上記以外の小節は無音ノーツを使用していない、通常配置です。