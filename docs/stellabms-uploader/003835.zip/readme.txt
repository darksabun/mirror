本体URL: https://dropbox.bms.ms/u/28765267/er_new-earth.zip
ガチ押し譜面です。この曲でやりたい配置を全部置きました。
下位差分の方は比較的マシな譜面になってると思います…一応

_newearth_sph.bmeと比較してズレはありません。