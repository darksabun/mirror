-Never ending journey- [Journey's End]

BPM:144 ガチ押し 推定難易度:st7 NOTES:2453 TOTAL:448

同梱譜面(-Never_ending_journey-[NORMAL].bms)と比較してズレ抜け無し

本体URL
　→https://manbow.nothing.sh/event/event.cgi?action=More_def&num=113&event=127