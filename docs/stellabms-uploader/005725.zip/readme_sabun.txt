A []
SHK / obj: Mary_Sue

本体：https://mega.nz/file/Tl9FVLxJ#20jx-8NLt8lrhL2FqLFSBh5moeQzRnslM5p9CGSvy8s
推定レベル：★23-24

A_h_2.bms基準ズレ抜けなし
よろしくお願いいたします。

Mary_Sue (https://darksabun.github.io/Mary_Sue/ or @MarySue_BMS)
2025/06/10