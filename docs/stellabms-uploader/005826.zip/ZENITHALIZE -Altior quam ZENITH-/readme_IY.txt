ZENITHALIZE -Altior quam ZENITH-

BPM:150 推定難易度:★★6 NOTES:3563 TOTAL:642

同梱譜面(+072 ZENITHALIZE [SPN].bme)と比較してズレ抜け無し

本体URL
　→https://electro-planet.net/loveplus/zenithalize.html