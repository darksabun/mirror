I-SSV -F1NALE- / -GR4ND F1NALE-

BPM:220 推定難易度:★★5/★★6 NOTES:4382/5126 TOTAL:833(0.19)/1231(0.24)

曲改変あり

本体URL
　→https://manbow.nothing.sh/event/event.cgi?action=More_def&num=48&event=116