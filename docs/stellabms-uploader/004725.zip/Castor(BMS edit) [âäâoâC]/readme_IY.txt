Castor(BMS edit) [ヤバイ]

BPM:140 ガチ押し 推定難易度:st10 NOTES:3475 TOTAL:777

同梱譜面(cstr_N.bms)と比較してズレ抜け無し

本体URL
　→http://manbow.nothing.sh/event/event.cgi?action=More_def&num=50&event=93