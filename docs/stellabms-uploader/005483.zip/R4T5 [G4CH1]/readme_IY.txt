R4T5 [G4CH1]

BPM:148 推定難易度:st6 NOTES:2868 TOTAL:517

同梱譜面(__R4T5_Another.bms)と比較してズレ抜け無し

本体URL
　→https://manbow.nothing.sh/event/event.cgi?action=More_def&num=10&event=127