stardust explorer
kooridori (movie : Arishima_)
OBJ. Atharnal
本体 : https://manbow.nothing.sh/event/event.cgi?action=More_def&num=146&event=140
推定レベル：Sl4~5?

ズレ チェック :  _blank.mihaichixxx とのズレなし


27番目の差分。
よろしくお願いいたします。

-Atharnal (discord : Atharnal#2977)