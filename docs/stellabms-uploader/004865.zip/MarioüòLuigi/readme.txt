元ネタ：マリオ＆ルイージRPGの中ボス戦　更なるお手並み拝見！

音量バランス、不協和音、本来なっていないシンバルなどは見逃してください。
歪んだ追加音源もあります。

想定難易度
marioH / 通常lv9
marioA / sl3
marioBA / st4
marioGOD / ★★6

参考動画
・マリオ&ルイージRPG　更なるお手並み拝見! / Come On, Again!　Piano Cover
https://www.youtube.com/watch?v=ZvUdzC2NADo&list=WL&index=1

・[修正版]マリオ＆ルイージRPGボス戦RSEアレンジ 更なるお手並み拝見！
https://www.youtube.com/watch?v=xUgq2vgIYuQ

・マリオ&ルイージRPGBGM【更なるお手並み拝見！】
https://www.youtube.com/watch?v=kVozsmX9RHA

・[15分耐久] 更なるお手並み拝見！DX マリオ＆ルイージRPG1DX
https://www.youtube.com/watch?v=QCQkwOKAZcc&t=53s