Blessed Memories [Ain't too proud to rely on!]

BPM:212 推定難易度:st7 NOTES:3639 TOTAL:765

同梱譜面(___14_spa.bme)と比較してズレ抜け無し

本体URL
　→https://k-bms.com/party_pabat/party.jsp?board_num=23&num=30&order=reg&odtype=a&ckattempt=1