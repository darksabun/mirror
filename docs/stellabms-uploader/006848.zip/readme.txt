[本体URL]
https://venue.bmssearch.net/bms_coffee/4

[ズレ抜け]
同梱 _OrangeJuice_vvv_00SPnoobj.bmx とズレ抜け無し

[NOTES / TOTAL]
1800 notes / 400 (0.222)

[雑記]
本家にたまにある、「発狂換算するとほぼ難易度ないけど配置が整っててやってて楽しかったりさくっとフルコンするのが楽しい譜面」を目指して作った
さくっとフルコンとか言ってる割にLNと皿の絡みがキツいのは許してください
★3くらいの難易度

[譜面リファレンス]
Illusionary Waterlily / DJ Noriken
Roar of Chronos / KE!JU