本体:https://manbow.nothing.sh/event/event.cgi?action=More_def&num=399&event=140
同梱INSANEと比較してズレ抜け無し