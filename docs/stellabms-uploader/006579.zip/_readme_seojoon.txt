TITLE:	RAT ATTACK
URL:	https://manbow.nothing.sh/event/event.cgi?action=More_def&num=35&event=149
LEVEL:	sl1?

for 「BOF:21差分企画」


키음 추가 커팅으로 인한 엇갈림이 있습니다. 이외에는 동봉 노말과 엇갈림 없음.
キー音追加カットによるズレがあります。それ以外は同梱ノーマルとズレなし。


2025.10.18 seojoon