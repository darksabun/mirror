(st6?)
HARDHOME feat.Megpoid [HARDGACHI]

本体URL:
https://venue.bmssearch.net/bmstukuru2025/19

ズレ抜けについて
	意図的なキー音の追加あり
	同梱[ANOTHER](_7a.bms)とbms diff toolで比較して、ズレ抜け無し