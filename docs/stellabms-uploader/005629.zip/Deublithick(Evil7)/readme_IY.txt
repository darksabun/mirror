Deublithick(Evil7)

BPM:228 推定難易度:st8 NOTES:1890 TOTAL:378

同梱譜面(Deublithick_5c7.bme)と比較してズレ抜け無し

本体URL
　→https://manbow.nothing.sh/event/event.cgi?action=More_def&num=171&event=74