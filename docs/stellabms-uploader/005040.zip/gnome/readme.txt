本家URL
https://manbow.nothing.sh/event/event.cgi?action=More_def&num=228&event=137

意図的にゴミ譜面を作りました
手動ディレイあり
太いノーツでプレイしてる方はノーツが重なる場合があるので要注意

本家のSPL譜面は▼17に採用されてる神譜面なのでぜひプレイしてください