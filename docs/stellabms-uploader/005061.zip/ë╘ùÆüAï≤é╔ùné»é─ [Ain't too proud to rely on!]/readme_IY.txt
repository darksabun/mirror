花嵐、空に溶けて [Ain't too proud to rely on!]

BPM:156 推定難易度:st7 NOTES:2929 TOTAL:600

意図的なキー音の追加やキー音の削除を含むアレンジ差分の為ズレ抜けチェック不可

本体URL
　→https://manbow.nothing.sh/event/event.cgi?action=More_def&num=25&event=142