本体:https://manbow.nothing.sh/event/event.cgi?action=More_def&num=244&event=146
同梱_BMS.bmsとズレ抜けなし
緋音月 [接触性危機](http://www.dream-pro.info/~lavalse/LR2IR/search.cgi?mode=ranking&bmsid=338495)
を参考に作成させていただきました。
