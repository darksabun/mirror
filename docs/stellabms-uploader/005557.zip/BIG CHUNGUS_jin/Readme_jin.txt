本体:https://drive.google.com/file/d/1iKZ3BavYnb-g08uUWDmqq3UAE2S6JBpw/view?usp=sharing
AYhaz氏によるアレンジ差分(http://www.dream-pro.info/~lavalse/LR2IR/search.cgi?mode=ranking&bmsid=301512)の差分
微アレンジ+停止一か所追加あり