(st3?) 仕事終了後超光速前進？？目標☆中華料理店！ (SP 満漢全席)

本体URL:https://manbow.nothing.sh/event/event.cgi?action=More_def&num=290&event=146

ズレ抜けについて
	意図的なキー音の追加があります
	同梱(SP 折耳根炒臘肉)(_SPA_13.bms)とbms diff toolで比較して、ズレ抜けが無いことを確認しています