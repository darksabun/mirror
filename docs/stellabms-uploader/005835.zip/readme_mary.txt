Deep Sea Girl [Vesper]
Utuka / obj: Mary_Sue

本体：https://manbow.nothing.sh/event/event.cgi?action=More_def&num=19&event=144
推定レベル：★20-21

STELLAでズレ抜けチェックはもういらなくなったのでやらなかったんです。
NORMAL譜面基準でズレや抜けはないんだと思います、多分…
それはとにかくよろしくお願いします！

Mary_Sue (https://darksabun.github.io/Mary_Sue/ or @MarySue_BMS)
2025/07/04