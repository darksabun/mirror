同時押しメインです。
sl10くらい？
bms diff toolにてズレ無し確認済み。