FREAKOUT [Ain't too proud to rely on!] / [FULL MARATHON]

BPM:150 推定難易度:★★5/★★5 NOTES:3333/3914 TOTAL:667/783

手動ディレイによる意図的なキー音の追加があります(FULL MARATHON)

両差分共に同梱譜面と比較してズレがありますが全てのズレは意図的なものです。

本体URL
　→https://manbow.nothing.sh/event/event.cgi?action=More_def&num=319&event=137