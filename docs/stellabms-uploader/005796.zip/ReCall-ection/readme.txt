本体:https://bmssearch.net/bmses/XyleYJepYncT5t
難易度:st11?(自分の実力不足で正確な難易度は分かりません…ｽﾐﾏｾﾝ…)
total:999

