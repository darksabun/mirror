https://manbow.nothing.sh/event/event.cgi?action=More_def&num=566&event=110

AnzuBMS Diff Toolでズレ検査済みです。
（差分用.bmsを基準に、追加キー音オブジェクトが1つ含まれています）