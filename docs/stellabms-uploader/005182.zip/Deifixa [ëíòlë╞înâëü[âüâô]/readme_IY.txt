Deifixa [横浜家系ラーメン]

BPM:142 推定難易度:st8 NOTES:2907 TOTAL:611

同梱譜面(deifixa_7a.bms)と比較してズレ抜け無し

本体URL
　→https://k-bms.com/party_pabat/party.jsp?board_num=25&num=1&order=reg&odtype=a