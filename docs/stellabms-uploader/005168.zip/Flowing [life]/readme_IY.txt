Flowing [life]

BPM:130 推定難易度:st8 NOTES:2928 TOTAL:557

同梱譜面(_Flowing_bga_SPA.bms)と比較してズレ抜け無し

本体URL
　→https://venue.bmssearch.net/bmstukuru2024/14