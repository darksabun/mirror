レシュノルティア
あとぅす feat.はらもりよしな(BGI:りーふぱいザウルス)
OBJ. Atharnal
本体 : https://venue.bmssearch.net/hanadayori/21
推定レベル：Sl3

ズレ チェック :   ___normal.bms とのズレなし


37番目の差分。
よろしくお願いいたします。

-Atharnal (discord : Atharnal#2977)
-Twitter : https://twitter.com/atharnal