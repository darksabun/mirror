君の心の荒ぶる神が
 　　　↘︎
 　生きる道を開く
 　　↙︎
 吹き荒れる風闇を走る雷
 　　　　↘︎
 嵐を呼び切開いてく
 　　　　 ↙︎
 ＿人人人人人人人人人人人人＿
 ＞　荒れた大地ィィ〜〜⤴︎　＜
 ￣Y^Y^Y^Y^Y^Y^Y^Y^Y^Y^Y

ありえない位置に無音ノーツ使ってるので何でも許せる人向けです
hujin_a.bmeと比較してズレはありません
本体:http://manbow.nothing.sh/event/event.cgi?action=More_def&num=235&event=65