本体:https://mega.nz/folder/BDJAhJDJ#BrSjRbk10U_uFphI7JG_xg/file/xOhWXTSI
難易度:	st6？
total:700
ズレ:手動ディレイによるズレあり