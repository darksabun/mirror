thank you for downloading! enjoy.

Lapis [astra/domini] ★★5(st8) 連打(jack)
Lapis [astra/crepitans] ★★6(st11) ディレイ、階段(delay, speed)

author:Criyajuh