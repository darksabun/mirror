奥多摩トランス [Ain't too proud to rely on!]

BPM:142 推定難易度:st9 NOTES:3435 TOTAL:619

同梱譜面(okutama -ANOTHER-.bme)と比較してズレ抜け無し

本体URL
　→https://manbow.nothing.sh/event/event.cgi?action=More_def&event=116&num=142