ビタースイート・サンデー[HOLIDAY]　★11（sl6)

本体URL:https://manbow.nothing.sh/event/event.cgi?action=More_def&num=50&event=142

同梱4_another.bmsとズレ抜け無し 無音ノーツあり