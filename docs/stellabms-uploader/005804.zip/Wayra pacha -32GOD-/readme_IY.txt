Wayra pacha -32GOD-

BPM:140 推定難易度:★★5 NOTES:3476 TOTAL:626

手動ディレイによる意図的なキー音の追加あり

本体URL
　→https://drive.google.com/file/d/1INY1pOc82NPELJnsM6BE1RA84x2GysGp/view?usp=drive_link