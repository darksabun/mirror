フーディー・バニーガール [Rabbit Tail]

本体URL:https://manbow.nothing.sh/event/event.cgi?action=More_def&num=9&event=147
HoodyBunnyGirl_Aとズレ抜けなし 無音ノーツあり
★10 sl6?