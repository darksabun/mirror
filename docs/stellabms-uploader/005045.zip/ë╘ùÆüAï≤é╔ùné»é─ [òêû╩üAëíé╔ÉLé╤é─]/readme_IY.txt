花嵐、空に溶けて [譜面、横に伸びて]

BPM:156 推定難易度:st0 NOTES:2461 TOTAL:517

意図的なキー音の追加やキー音の削除を含むアレンジ差分の為ズレ抜けチェック不可

本体URL
　→https://manbow.nothing.sh/event/event.cgi?action=More_def&num=25&event=142