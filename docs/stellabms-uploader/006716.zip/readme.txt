[本体URL]
https://manbow.nothing.sh/event/event.cgi?action=More_def&num=42&event=149

[ズレ抜け]
同梱__ESPITZ_IDENCY_00_blanc.bmxとズレ抜け無し

[NOTES / TOTAL]
2700 notes / 543 (0.201)

[雑記]
良い感じの微縦と24分
発狂っぽい配置だけどギリギリ音拾ってるのがわかる感じとか、
たまに混ざる本家っぽいLNとかを意識した

[譜面リファレンス]
（どれもあんまり似てはない）
Unbelief / Anonymous
Vitrum / Yvya
DAYBREAK [FUTURE7] / Lime / Kankitsu, potechang