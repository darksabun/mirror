Stay with me (7key Maryther BGA)
Pinky feat.L'Ile / obj.Mary_Sue

推定レベル：★18?
本体：https://mega.nz/folder/EpgWgJqa#7OItZfYLQxZ0X8OB19yvNQ/file/wtR1EZgD

同梱pinky_staywithme_5nb基準ズレ抜けなし。

よろしくお願いいたします。
Mary_Sue (https://darksabun.github.io/Mary_Sue/ or @MarySue_BMS)
2024/04/28