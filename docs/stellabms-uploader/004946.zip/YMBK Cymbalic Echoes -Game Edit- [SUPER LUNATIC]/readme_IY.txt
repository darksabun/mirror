YMBK "Cymbalic Echoes" -Game Edit- [SUPER LUNATIC]

BPM:205 推定難易度:st5 NOTES:3533 TOTAL:707

キー音の追加あり

同梱譜面(_ YMBK [SP NORMAL].bme)と比較して追加したキー音以外のズレ抜け無し

本体URL
　→https://manbow.nothing.sh/event/event.cgi?action=More_def&num=25&event=129