Lightstep [Ain't too proud to rely on!]

BPM:128 ガチ押し 推定難易度:st1 NOTES:2067 TOTAL:325

同梱譜面(lightstep_5.bms)と比較してズレ抜け無し

本体URL
　→https://drive.google.com/file/d/1ZXGtdvAeiB8ts_Spd4NGUkgoRANYuTqT/view?usp=drive_link