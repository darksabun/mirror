(st3?)
ほしのねがい [Milky Way]

本体URL:
https://drive.usercontent.google.com/download?id=1TdDDTPVmx_Ydx797h0EQNHTcCp0gXvPF&export=download&authuser=0

ズレ抜けについて
	意図的なキー音の追加あり
	同梱[SP ANOTHER](hoshino_negai_SPA.bms)とbms diff toolで比較して、ズレ抜けなし