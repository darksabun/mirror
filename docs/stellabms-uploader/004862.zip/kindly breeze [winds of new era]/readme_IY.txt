kindly breeze [winds of new era]

BPM:128 推定難易度:st9 NOTES:3478 TOTAL:635

同梱譜面(kindly breeze_N.bms)と比較してズレ抜け無し

本体URL
　→https://dropbox.bms.ms/u/87133313/BMS/kindly%20breeze%20.zip