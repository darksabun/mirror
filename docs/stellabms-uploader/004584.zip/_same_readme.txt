Magical Night Special [サメ]
Song URL: https://manbow.nothing.sh/event/event.cgi?action=More_def&num=413&event=146
Estimated Difficulty: sl4 (★7)
Based on SPN