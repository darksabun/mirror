(sl12,★19?) ラスティゲート [Nebula]

本体URL:
https://venue.bmssearch.net/bmstukuru2025/65

[Insane]と比較してズレ抜けなし
