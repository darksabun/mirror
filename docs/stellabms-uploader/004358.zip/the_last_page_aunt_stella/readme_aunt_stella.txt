st5? The Last Page [Reminiscence]

ARForest / inukoro / obj:Stellaおばさん

同梱「TheLastPage_15_SPI.bms」と比較してズレ抜け無し。（Anzu BMS Diff Toolで確認）

本体URL
http://manbow.nothing.sh/event/event.cgi?action=More_def&num=163&event=127