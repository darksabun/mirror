Akasagarbha [秋刀魚]

BPM:192 推定難易度:st9 NOTES:2888 TOTAL:694

キー音の追加あり

同梱譜面(_akasagarbha_7a.bme)と比較して追加したキー音以外のズレ抜け無し

本体URL
　→https://web.archive.org/web/20130824160600/http://3t1a.net/bms/Akasagarbha_ogg.rar