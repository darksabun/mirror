わるいコ
nekomimi_STRaw
OBJ. Atharnal
本体 : https://manbow.nothing.sh/event/event.cgi?action=More_def&num=311&event=137
推定レベル：Sl9~sl10

ズレ チェック : _templete.bms とズレなし


よろしくお願いいたします。

-Atharnal (discord : Atharnal#2977)