(st6?)
地外桃源 [Delay Utopia]

本体URL(保管):
https://bms.wrigglebug.xyz/download/%E5%9C%B0%E5%A4%96%E6%A1%83%E6%BA%90.7z


ズレ抜けについて
	キー音アレンジやBPM変化の削除によりズレチェック不可
	同梱ANOTHER譜面(chigaitougen_another)とbms diff toolで比較して検出されるズレ抜けは全て意図的です。