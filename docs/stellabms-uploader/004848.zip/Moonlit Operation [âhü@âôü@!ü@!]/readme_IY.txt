Moonlit Operation [ド　ン　!　!]

BPM:175 推定難易度:st5 NOTES:2769 TOTAL:514

手動ディレイによるキー音追加あり

同梱譜面(_Moonlit_Operation_SPN.bms)と比較して追加キー音以外のズレ抜け無し

本体URL
　→https://manbow.nothing.sh/event/event.cgi?action=More_def&num=31&event=142