!nterroban(?, [Ain't too proud to rely on!]

BPM:220 推定難易度:st7 NOTES:3485 TOTAL:732

キー音の追加あり

同梱譜面(_interrobang_B.bms)と比較して追加したキー音以外のズレ抜け無し

本体URL
　→https://manbow.nothing.sh/event/event.cgi?action=More_def&num=407&event=137