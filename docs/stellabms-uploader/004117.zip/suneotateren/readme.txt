初差分です。
曲改変あります。
逆走バージョンもあります。
本体(LR2IR):http://www.dream-pro.info/~lavalse/LR2IR/search.cgi?bmsmd5=f5fc6cf48b33b1fceaf40127d1d99d20