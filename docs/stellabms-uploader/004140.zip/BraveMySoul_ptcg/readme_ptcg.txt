Brave My Soul [Destiny]

本体:https://manbow.nothing.sh/event/event.cgi?action=More_def&num=93&event=116

ズレ抜けについて
	同梱ANOTHER譜面(_ano.bms)とbms diff toolで比較して、ズレ抜けがないことを確認しています。