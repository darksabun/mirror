糸引く夏のエデンにて。 
(st4?) [Paradise Lost]
(st9?) [Predestined Story]

本体:https://manbow.nothing.sh/event/event.cgi?action=More_def&num=189&event=140

同梱しているoggファイルも導入してください。


ズレ抜けについて
	
[Paradise Lost]
	同梱[Insane](7key_Insane.bms)とbms diff toolで比較して検出される全てのズレ抜けは、BPM変化の削除によるもので意図的です。

[Predestined Story]
	後半にアレンジを加えているためズレチェック不可。
	同梱[Insane](7key_Insane.bms)とbms diff toolで比較して検出される全てのズレ抜けは、意図的なものであることを確認しています。