Affection [GOD]

BPM145 乱打/微縦連　推定難易度:st6 NOTES:3075 TOTAL:587

無音ノーツを使っています

同梱譜面(3-spa_affection.bms)と比較してズレ抜け無し

本体URL
　→https://www.mediafire.com/file/ggy0zvn5i87ke64/Xacla-Affection_ogg.zip/file