URL: https://manbow.nothing.sh/event/event.cgi?action=More_def&num=21&event=147

- Additional keysounds included.
- BGA for LR2 included:
  - Please rename the file: `FACESES.avi_LR2` → `FACESES.avi`
  - You can ignore or delete this file if your BMS player already supports `.avi` format BGAs.