The Island of Albatross [Sorrow of Albatross]

BPM:148 推定難易度:★★5 NOTES:3100 TOTAL:713(0.230%/N)

ソフラン削除に伴うズレ抜けあり

本体URL
　→https://drive.google.com/file/d/1JF5y9xeUB0GSZspTpeYMFAd7dU1ItHUV/view?usp=drive_link