[Hard-] sl6(★10)?
[Hard] sl8(★14)?

BPM142の32分ディレイ
dy2 [styx] と比較してズレ・抜けなし

本体→ https://onedrive.live.com/?cid=FC95A680740CA8C9&id=FC95A680740CA8C9%21292&parId=FC95A680740CA8C9%21111
追加音源→ https://drive.google.com/file/d/1gQvTYuNckle1fpepgWs0AxPa-9bYOPwD/view?usp=drive_link