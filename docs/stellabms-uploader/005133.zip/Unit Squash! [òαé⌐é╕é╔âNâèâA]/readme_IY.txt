Unit:Squash! [歩かずにクリア]

BPM:151 推定難易度:st8 NOTES:3040 TOTAL:654

同梱譜面(_spa.bme)と比較してズレ抜け無し

本体URL
　→https://manbow.nothing.sh/event/event.cgi?action=More_def&num=16&event=142