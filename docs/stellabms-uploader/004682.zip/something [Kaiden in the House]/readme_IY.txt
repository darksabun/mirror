something [Kaiden in the House]

BPM124 ガチ押し　推定難易度:st5～6 NOTES:2231 TOTAL:346

無音ノーツを使っています

同梱譜面(something_n.bms)と比較してズレ抜け無し

本体URL
　→https://manbow.nothing.sh/event/event.cgi?action=More_def&num=220&event=127