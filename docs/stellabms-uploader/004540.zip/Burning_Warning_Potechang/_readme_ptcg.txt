(st3?) Burning×Warning! [Training×Widening!]

本体URL:https://manbow.nothing.sh/event/event.cgi?action=More_def&num=146&event=146

ズレ抜けについて
	意図的なキー音の追加があります
	同梱[SP ANOTHER](SP_A.bms)とbms diff toolで比較して、ズレ抜けが無いことを確認しています