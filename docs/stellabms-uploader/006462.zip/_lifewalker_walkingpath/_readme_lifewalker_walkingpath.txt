st7? Nightwalker [Lifewalker]
st2? Nightwalker [Wakingpath]

tomo3_chan BGA: tomo3_chan obj:E

�{��URL
https://manbow.nothing.sh/event/event.cgi?action=More_def&num=52&event=149
