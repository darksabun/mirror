(st6?) クナイ☆フィーバー [微縦☆フィーバー]

本体URL:
https://venue.bmssearch.net/bmstukuru2025/15

ズレ抜けについて
	意図的なキー音の追加があります
	同梱[ANOTHER](_KUNAIFEVER(SPA).bms)とbms diff toolで比較して、ズレ抜け無し