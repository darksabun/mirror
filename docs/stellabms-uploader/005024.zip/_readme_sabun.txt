Inochi Dancing [Doom]
Yozora Mixtape / obj: Mary_Sue

本体：https://drive.google.com/file/d/1lkEN0c4Ma9e18siJffQneF60La4pTMJ8/view?usp=drive_link
推定レベル：★3-4?

_0dancing.bml基準ズレ抜けなし
よろしくお願いいたします。

Mary_Sue (https://darksabun.github.io/Mary_Sue/ or @MarySue_BMS)
2025/02/04