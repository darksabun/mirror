本体:https://manbow.nothing.sh/event/event.cgi?action=More_def&num=152&event=88
アレンジ差分のためズレ抜けあり