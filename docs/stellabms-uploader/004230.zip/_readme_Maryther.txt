holicチョコ [7K MARYTHER]
Du Vel Mat Te / OBJ: Mary_Sue BGI: morph

本体：https://morph-pack.netlify.app/
推定レベル：★24-25?
_holicchoco.bme基準ずれ抜けなし

動画の録画はM-SPINさんがしてくださり、大変助かりました。
よろしくお願いいたします。

2024/07/26
Mary_Sue (https://darksabun.github.io/Mary_Sue/ or @MarySue_BMS)