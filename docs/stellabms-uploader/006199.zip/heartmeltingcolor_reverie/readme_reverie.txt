本体
https://manbow.nothing.sh/event/event.cgi?action=More_def&num=31&event=96

Heart Melting Color [Reverie] ★15/sl9?

BPM200ハネズレ同時
自分が特に得意な譜面傾向なので少し査定が不安です
sl11の結ばれる奇跡の願い[Shining]やst1の同曲差分[ ]とかと比べると易しめ

【BGIについて】
本差分は新たにBGIを同梱しています
導入時点でこの差分[Reverie]はbeatoraja/LR2でうつるはずです
(作成につき本体同梱のback.bmpをお借りしました)

以下beatoraja限定
同梱している「bgi.png」をコピーしたうえで「bg.png」にすると他の譜面でもBGIがうつります