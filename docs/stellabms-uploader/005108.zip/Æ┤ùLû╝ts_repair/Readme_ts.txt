本体:https://k-bms.com/party_pabat/party.jsp?board_num=24&num=15&order=reg&odtype=a
過去上げた差分のバランス+totalの調整をしたものになっております。
同梱Nと比較してズレ抜けなし