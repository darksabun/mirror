st3? Faraway Sky (All I C Is U) [Fly Away]

Kyuzo Sameura obj:E

_noobj.bms.000と比較してズレ抜け無し

本体URL
https://9domu46i.com/yuruyuru/phase23.html