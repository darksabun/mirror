Distress (BMS Edit) [Agony]
TECHMI a.k.a. SAMPLING GROOVE BOX | Mov. abelest / Prod. PALOW / Object. Mary_Sue

本体：https://www.dropbox.com/s/qr7r0mkvs1r233u/sgb_Distress.zip?dl=1
推定レベル：★11~12?

distress_7とズレ抜けなし。
よろしくお願いいたします。

Mary_Sue (https://darksabun.github.io/Mary_Sue/ or @MarySue_BMS)
2024/03/17