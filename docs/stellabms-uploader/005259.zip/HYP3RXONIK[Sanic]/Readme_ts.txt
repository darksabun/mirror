本体:https://k-bms.com/party_pabat/party.jsp?board_num=25&num=35&order=reg&odtype=a
__H37K.bmsと比較してズレ抜けなし