深夜テンションで譜面置いてたらこうなってた。
Freq下げて他の譜面と比較してみたらst2くらいあった。
そのうち自分でもクリアしたい。

本体: https://venue.bmssearch.net/bmstukuru2023/2
diffチェック済み