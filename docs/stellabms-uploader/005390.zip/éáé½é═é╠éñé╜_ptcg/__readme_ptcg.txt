(st2?)
あきはのうた [よこにひろい]

本体URL:
https://drive.usercontent.google.com/u/0/uc?id=1ziRN0mQkfbpSGIbMdlnud9200kcdJ7nt&export=download

ズレ抜けについて
	BPM変化の削除と意図的なアレンジを加えているため、ズレチェック不可
