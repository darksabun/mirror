Transcend to Heaven [Reason for life]

BPM:142 推定難易度:★★5 NOTES:3388 TOTAL:610

同梱未配置(tth_unplaced.bms)と比較してズレ抜け無し

本体URL
　→https://manbow.nothing.sh/event/event.cgi?action=More_def&num=65&event=142