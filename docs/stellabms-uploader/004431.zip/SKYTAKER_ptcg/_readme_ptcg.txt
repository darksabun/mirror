(st2?) SKYTAKER [Re:START]

本体URL:https://manbow.nothing.sh/event/event.cgi?action=More_def&num=5&event=146

ズレ抜けについて
	意図的なキー音の追加があります
	同梱[Another](_7key_Another.bms)とbms diff toolで比較して、ズレ抜け無し