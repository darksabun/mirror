本体:https://manbow.nothing.sh/event/event.cgi?action=More_def&num=49&event=149

1分超えwav(bass3_001.ogg)が含まれLR2IRに送信できなかったため、すみませんが勝手にカットしました。
譜面と一緒に曲フォルダに入れてください。
_normal_wavcut.bmは上記音源を差し替えた同梱normal譜面となっております。

なおsnare6_000.oggも1分越えですがこちらは使用されていないためノータッチです。