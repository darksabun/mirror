本家URL
https://venue.bmssearch.net/tohobmsr/8


動作確認環境 : beatoraja

st1想定のガチ押しで、譜面はst0ですが低TOTAL値でst1だと思います。
本家の_7k lunatic譜面とズレ確認しましたがミスってたらごめんなさい。

