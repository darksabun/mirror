本体:https://venue.bmssearch.net/bmstukuru2025/2
アレンジのため全体的にズレ抜け有