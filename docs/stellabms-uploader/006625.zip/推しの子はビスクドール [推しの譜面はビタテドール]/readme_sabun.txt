推しの子はビスクドール [推しの譜面はビタテドール]

sl4? 同梱HYPER譜面とズレ抜け無し 無音ノーツあり

https://manbow.nothing.sh/event/event.cgi?action=More_def&num=260&event=149