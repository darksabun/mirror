[本体URL]
https://manbow.nothing.sh/event/event.cgi?action=More_def&num=177&event=149

[ズレ抜け]
同梱 7NORMAL.bms とズレ抜け無し（重複のみ削除）

[NOTES / TOTAL]
2400 notes / 555 (0.231)

[雑記]
260の12分・16分・32分
折り返しを楽しめる密度の配置
ラス殺しなので怪しいけど★18くらい？

[譜面リファレンス]
Mare Nectaris / 神楽
Somnidiscotheque / 夢路 歩