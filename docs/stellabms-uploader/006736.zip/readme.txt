[本体URL]
https://manbow.nothing.sh/event/event.cgi?action=More_def&num=72&event=149


[ズレ抜け]
同梱_Trusted Triangle__templateをベースに作成
下記の意図的な変更を除いてズレ抜け無し

・#WAVIAを63小節目1拍目→64小節目1拍目に移動


[NOTES / TOTAL]
3231 notes / 582 (0.180)

[雑記]
みんな大好きblack opal [Pentagon]のオマージュ
ただし曲が元気だったのでそれっぽい要素（皿とジャリ）は惜しみなく配置
BPM落ちてるのと折り返しを控えめにしたのとで本家よりだいぶ簡単目な気がする


[譜面リファレンス]
black opal [Pentagon] / TAK vs General, hex
Verflucht†LEGGENDARIA / Tyrfing
同梱SPI