BonUStimE! [LUDICROUS] / CYAN (movie : ywj0212) / obj:どくだみ草
本体:https://manbow.nothing.sh/event/event.cgi?action=More_def&num=381&event=149
難易度:sl12

音切られてなかったので音切りに挑戦してみました。
音切りしない方がマシだったので、お蔵入りになりました。
悲しいね。

譜面はsl12入門を想定した重発狂乱打です。
Totalは高いので頑張ってください。