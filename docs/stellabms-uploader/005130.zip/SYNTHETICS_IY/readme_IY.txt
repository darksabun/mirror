SYNTHETICS [ごめんなさい]

BPM:160 推定難易度:st11 NOTES:4000 TOTAL:1000

SYNTHETICS [Nerd Techniques_fix]

BPM:160 推定難易度:st13 NOTES:4444 TOTAL:1079

手動ディレイによるものや意図的なキー音の追加があります

同梱譜面(SYNTHETICS ANOTHER.bms)と比較して追加したキー音以外のズレ抜け無し

本体URL
　→https://manbow.nothing.sh/event/event.cgi?action=More_def&num=285&event=123