(st4?)
糸引く夏のエデンにて。 [Paradise Lost]

本体:https://manbow.nothing.sh/event/event.cgi?action=More_def&num=189&event=140

ズレ抜けについて
	同梱[Insane](7key_Insane.bms)とbms diff toolで比較して検出される全てのズレ抜けは、BPM変化の削除によるもので意図的です。