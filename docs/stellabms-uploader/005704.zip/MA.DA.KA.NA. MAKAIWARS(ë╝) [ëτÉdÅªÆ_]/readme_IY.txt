MA.DA.KA.NA. MAKAIWARS(仮) [臥薪嘗胆]

BPM:235 推定難易度:st11 NOTES:5154 TOTAL:1031

キー音の追加あり

同梱譜面(01_mdkn_n.bme)と比較して追加したキー音以外のズレ抜け無し

本体URL
　→https://manbow.nothing.sh/event/event.cgi?action=More_def&num=140&event=83