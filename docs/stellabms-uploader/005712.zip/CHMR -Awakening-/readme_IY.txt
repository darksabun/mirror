CHMR -Awakening-

BPM:195 推定難易度:st5 NOTES:2663 TOTAL:533

同梱譜面([CRYSTAL TECHNOLOGY]CHMR[SP BEGINNER].bme)と比較してズレ抜け無し

本体URL
　→https://tz-kt-lc.tumblr.com/