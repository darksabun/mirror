(st5?) Infinite Dreams [Eternal Promise]

本体URL:https://manbow.nothing.sh/event/event.cgi?action=More_def&num=43&event=142

ズレ抜けについて
	bms diff toolにて同梱[BEGINNER](__beginner.bms)と比較して、ズレ抜けが無いことを確認しています。