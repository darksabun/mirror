ファクトフィクション [ファクトフィジ横クション]
本体:https://manbow.nothing.sh/event/event.cgi?action=More_def&num=4&event=144

ズレ抜けについて
	同梱BlackAnother(Fact_Fiction_BlackAnother.bms)とbms diff toolで比較して、ズレ抜け無し(許容誤差1ms)
	ソフランを強引に追加しているので厳密には非常に小さなズレがありますが、意図的
	なにか問題があれば連絡貰えれば……