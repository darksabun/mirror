RedShift [SP NOMERCY]

BPM:145 推定難易度:st12 NOTES:3610 TOTAL:940

意図的にキー音を削除した箇所があるのでズレ抜けチェック不可
一応同梱譜面と比較して意図的に削除した箇所以外のズレ抜けは無し

本体URL
　→https://manbow.nothing.sh/event/event.cgi?action=More_def&num=91&event=133