Mazy Mermaid [Ain't too proud to rely on!]

BPM:145 推定難易度:st9 NOTES:3449 TOTAL:666

キー音の追加あり

同梱譜面(03_syeng_spa.bme)と比較して追加したキー音以外のズレ抜け無し

本体URL
　→https://manbow.nothing.sh/event/event.cgi?action=More_def&num=288&event=74