原曲URL
https://manbow.nothing.sh/event/event.cgi?action=More_def&num=492&event=133


差分その1
st1想定 [Go beyond the wall of the satellite]
notes : 2865
TOTAL値 : 600
ズレチェック : 同梱SPA譜面


差分その2
st4想定 [Go beyond the wall of release speed]
notes : 3345
TOTAL値 : 669
ズレチェック : 同梱SPA譜面


2譜面とも超高速乱打というよりbpm138のディレイに近い譜面で、正規は階段にしたので乱推奨
st1想定の方はLN固定で本当はサブタイトル通りst0ぐらいを想定していたのですが当たり引いてst0ぐらいだったのでst1に変更しました
st4想定の方はHCN固定にしてるのでoraja推奨譜面で、1か所不可能配置があると思われる方もいらっしゃると思いますが、
正規は12467のdp親切設計配置にしてるので不可能ではないです。レッツ片手プレー