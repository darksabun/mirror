冬霞 -冬の朝は寒い-

BPM:186  推定難易度:st8 NOTES:3274 TOTAL:686

キー音の追加や意図的なキー音削除によるアレンジがあるのでズレ抜けチェック不可

本体URL
　→https://venue.bmssearch.net/bmstukuru2025/95