Metcha Matcha Mondae!!![抹茶パフェ]

本体URL:https://manbow.nothing.sh/event/event.cgi?action=More_def&num=24&event=147
[A]Metcha_Matcha_Mondae.bmsとズレ抜け無し

★9 sl5?