Lament for Broken Puppet ⇒Side:M
[Cut/Work] ヒガシオイシン / ヒイラギジャジャマル obj: Mary_Sue

本体：https://drive.google.com/file/d/13a1TxQn6iAAjGryoQoxbWKAhPP0s-KZE/view?usp=drive_link
推定レベル：★11-13

アレンジ差分のため、ズレや抜けが発生しています。
よろしくお願いいたします。

Mary_Sue (https://darksabun.github.io/Mary_Sue/ or @MarySue_BMS)
2025/03/11