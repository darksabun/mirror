Artificial Queen [PK Love α]
Song: https://manbow.nothing.sh/event/event.cgi?action=More_def&num=217&event=149
Estimated difficulty: sl4~5?
Based on SPN