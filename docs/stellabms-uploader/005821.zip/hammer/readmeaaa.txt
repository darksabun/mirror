原曲URL
http://cool-create.cc/bms/index.html

糞譜面＝皿複合×HARD判定