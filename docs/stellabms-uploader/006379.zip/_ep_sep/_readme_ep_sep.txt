st2? SHINKA [EP]
st5? SHINKA [SEP]

�{��URL
https://manbow.nothing.sh/event/event.cgi?action=More_def&num=398&event=140