(st3?) すばらしい君にメイド服を [Intense]

本体:https://venue.bmssearch.net/tohobmsr/5

ズレ抜けについて
	同梱[Normal](_7k normal.bms)とbms diff toolで比較して、ズレ抜けが無いことを確認しています。