(st7?)
裁きの鐘 [HELL or HELL]

本体URL:
https://venue.bmssearch.net/bms-classic/4

ズレ抜けについて
	意図的なキー音の追加あり
	同梱[SP ANOTHER]とbms diff toolで比較して、ズレ抜け無し