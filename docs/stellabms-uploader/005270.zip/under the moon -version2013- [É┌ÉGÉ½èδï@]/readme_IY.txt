under the moon -version2013- [接触性危機]

BPM:180 推定難易度:★★1? NOTES:3754 TOTAL:601

同梱譜面(under_the_moon_7a.bms)と比較してズレ抜け無し

本体URL
　→https://cineraria-studio.com/?page_id=53