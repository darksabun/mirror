rand260

BPM:130 推定難易度:st10～11 NOTES:4510 TOTAL:993

手動ディレイ等による意図的なキー音の追加あり

同梱未配置(rand130_base.bms)と比較して追加したキー音以外のズレ抜け無し

本体URL
　→https://drive.google.com/file/d/10GXlYoVonh2DLBea15yFnTAl9eUvkOeE/view