RETROCONNECTION[Back To The 2000s]
obj:MiKaDo

本体URL:https://manbow.nothing.sh/event/event.cgi?action=More_def&num=376&event=142

難易度:★12 sl7

RETROCONNECTION_A.bmsとズレ抜け無し
※#058でRC、QXの定義が重複していますが、同梱譜面がその状態なため変更を加えていません。