NEW ANACHRONISM -もう、主人公になれない- [RAGE AGAINST]

BPM:222 推定難易度:st8 NOTES:4424 TOTAL:1064

キー音の追加あり

同梱譜面(23_asagi_ura_a.bme)と比較して追加したキー音以外のズレ抜け無し

本体URL
　→http://manbow.nothing.sh/event/event.cgi?action=More_def&num=192&event=65