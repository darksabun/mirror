MINUS-INFINITY [EARTH POWER]

BPM:191 推定難易度:st7 NOTES:3000 TOTAL:600

同梱されているoggファイルも一緒に導入してください

曲改変差分の為ズレ抜けチェック不可

本体URL(保管)
　→https://drive.google.com/file/d/11PeLy4ixD23ao7duMT8QC93hHa-TR5UO/view?usp=drive_link