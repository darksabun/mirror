st4ガチ押し
bms diff toolにてズレ無し確認済み。