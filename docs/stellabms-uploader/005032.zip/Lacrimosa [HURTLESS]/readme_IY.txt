Lacrimosa [HURTLESS]

BPM:222 推定難易度:st8 NOTES:3536 TOTAL:831

キー音の追加あり

同梱譜面(Lacrimosa_7normal.bms)と比較して追加したキー音以外のズレ抜け無し

本体URL
　→https://manbow.nothing.sh/event/event.cgi?action=More_def&num=255&event=140