宇宙葬 [WELTRAUMBESTATTUNG]
130 / obj: Mary_Sue

本体：https://drive.google.com/file/d/1qmqOE_ZVB9t2csfAZnk1706qWe09inS0/view?usp=drive_link
推定レベル：★19-20

_krampf.bmlとズレ抜けなし。
よろしくお願いいたします。

Mary_Sue (https://darksabun.github.io/Mary_Sue/ or @MarySue_BMS)
2024/05/08