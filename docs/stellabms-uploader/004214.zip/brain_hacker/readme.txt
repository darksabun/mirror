scrollを使ってみたかっただけのギミック脳トレ譜面です。
beatoraja推奨。
SUD+とLIFTはつけないほうが綺麗に見えるかも？