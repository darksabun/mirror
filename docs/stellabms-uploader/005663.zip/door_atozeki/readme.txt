door[あとぜき]

(本体URL)https://venue.bmssearch.net/bmstukuru2025/108

another.bmsとズレ抜け無し確認済み

◆(ln)10くらい？