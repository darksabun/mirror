Sijaelewa Chochote [Mwenyezi Mungu]
otoshi.b BGI:神宮要 / OBJ:Mary_Sue

本体：https://venue.bmssearch.net/genreshuffle4/57
推定レベル：★24-25

_Sijaelewa_Chochote_0notesとズレ抜けなし。
よろしくお願いいたします。

Mary_Sue (https://darksabun.github.io/Mary_Sue/ or @MarySue_BMS)
2024/05/04