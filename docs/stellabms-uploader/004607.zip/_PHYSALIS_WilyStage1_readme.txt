[BLOOM VGM]
DR. WILY STAGE 1 (PHYSALIS remix)

元BMS：
PHYSALIS / TAG

原曲：
DR. WILY STAGE 1 / 立石　孝（「ロックマン2　Dr.ワイリーの謎」　より）

rearr. nbunnyuwu

本体URL: https://manbow.nothing.sh/event/event.cgi?action=More_def&num=125&event=146

[SP ANOTHER] - ☆12