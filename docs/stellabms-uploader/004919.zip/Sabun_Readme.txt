planet:CHRONICLE-BMS Edit- [Chronica Astralis]
LittleJunker fw. nek*N-PRJ / obj: Mary_Sue

本体：https://mega.nz/file/eQZTRa7L#Lcl_Jb2ANbeOEsm-llFB4hD240VlUZ2pClxn8sfNkYc
推定レベル：★24

ANOTHERとずれ抜けなし
よろしくお願いいたします。

Mary_Sue (@MarySue_BMS or https://darksabun.github.io/Mary_Sue/)
2025/01/13