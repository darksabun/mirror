(st10?)
CUNNY TRIO [Immortal]

本体URL:
https://manbow.nothing.sh/event/event.cgi?action=More_def&num=28&event=148

ズレ抜けについて
	意図的なキー音の追加があります
	同梱[Normal](_cunnytrio_7n.bms)とbms diff toolで比較して、ズレ抜け無し