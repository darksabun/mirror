(st5?) Exipration [Intense]

本体URL:https://manbow.nothing.sh/event/event.cgi?action=More_def&num=35&event=146

ズレ抜けについて
	意図的なキー音の追加があります
	同梱ANOTHER(SPA.bms)とbms diff toolで比較して、ズレ抜けが無いことを確認しています