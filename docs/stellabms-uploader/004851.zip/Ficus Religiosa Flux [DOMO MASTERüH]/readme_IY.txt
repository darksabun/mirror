Ficus Religiosa Flux [DOMO MASTER?]

BPM:108 推定難易度:st4 NOTES:3039 TOTAL:478

同梱譜面(_Ficus Religiosa_Flux_sp_another.bms)と比較してズレ抜け無し

本体URL
　→https://drive.google.com/file/d/1KM5SkzKKEDx9AWOrrF5rKKRpSA3-FJ4J/view?usp=drive_link