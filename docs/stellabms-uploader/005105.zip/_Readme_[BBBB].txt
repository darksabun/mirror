Chainsaw NINJA vs ALIEN[BBBB]
kas_0120 vs hard
OBJ. Atharnal

本体 : http://manbow.nothing.sh/event/event.cgi?action=More_def&num=353&event=133
推定レベル：sl10

BPM : 170

ズレ チェック :  Chainsaw_NINJA_vs_ALIEN_7N.bme とのズレなし


よろしくお願いいたします。

-Atharnal (discord : Atharnal#2977)