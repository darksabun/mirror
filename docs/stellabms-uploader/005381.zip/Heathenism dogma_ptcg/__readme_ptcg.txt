(st5?) Heathenism dogma [Sacrifice]

本体URL(保管):
https://mega.nz/folder/BDJAhJDJ#BrSjRbk10U_uFphI7JG_xg/file/QeIgVTSY

ズレ抜けについて
	意図的なキー音の追加あり
	同梱[Another](_7A.bms)とbms diff toolにて許容誤差1msで比較して、ズレ抜け無し
	(厳密にはこれ以下の細かいズレがありますが、意図的)