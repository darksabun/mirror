(st5?) ティアラメンツ [Deep Ocean's MemOry]

本体URL:
https://venue.bmssearch.net/bmstukuru2025/92

ズレ抜けについて
	同梱[ルルカロス](TearLaments_SPI.bms)とbms diff toolで比較して、ズレ抜け無し