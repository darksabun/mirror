Memories in the Blue
otoshi.b (movie : FanfRS × はしたかさん)
OBJ. Atharnal
本体 : https://manbow.nothing.sh/event/event.cgi?action=More_def&num=7&event=142
推定レベル：sl11~12

ズレ チェック :  _memories_in_the_blue_00_0notes.bmx と キー音側には ズレなし

 - baseファイルと比較してmeta infoが修正されています。


40番目の差分。
よろしくお願いいたします。

-Atharnal (discord : Atharnal#2977)
-Twitter : https://twitter.com/atharnal