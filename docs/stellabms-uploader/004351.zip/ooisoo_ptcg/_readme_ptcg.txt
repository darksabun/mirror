(st0?) oo i s oo - Perfection - [33550336]

本体:https://www.dropbox.com/s/rsqq1z33lmci8lb/%5BPLEKTRUM%5Doo%20i%20s%20oo%20-Perfection-%5BTKR%5D.zip?dl=1

ズレ抜けについて
	手動ディレイによるキー音の追加があります。
	同梱[SP ANOTHER](ooisoo_SP12.bms)とbms diff toolで比較して、ズレ抜けがないことを確認しています。