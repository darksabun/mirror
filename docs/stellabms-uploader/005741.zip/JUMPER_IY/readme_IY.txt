お前らどうせ「今回も『JUMP』とか『跳』とか関連の単語をタイトルの中に入れるんだろうなー」とか期待していたんだろう？残念だがそう何度もJUMPネタで行くと思うなよ！俺だってそう何度もJUMP、JUMP言い続けたら飽きられるってことぐらい分かってるんだ！JUMPって言い続けた結果、JUMP本来の単語の意味が薄まるなんて状況にさせてたまるか！！！！(BMS edit) [Ain't too proud to rely on!] / [Ain't too proud to rely on!+]

BPM:190 推定難易度:★★5/★★6 NOTES:2652/2657 TOTAL:504/585

同梱譜面(01_moudameda_n.bms)と比較してズレ抜け無し

本体URL
　→https://dropbox.bms.ms/u/59483835/BMS/moudameda.rar