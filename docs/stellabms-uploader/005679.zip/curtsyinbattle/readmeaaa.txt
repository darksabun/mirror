原曲URL
https://venue.bmssearch.net/tohobmsr/43

イージー想定難易度st2
notes : 2585
TOTAL値 : 517

SPA譜面でズレ無し？ソフランの所いじった記憶ないのにズレ検出されますが、譜面自体はズレてないはず。

譜面は微縦で、前半は強くst3相当になっていますが、後半は回復も入れてst2相当にしてます。
初見殺しあり。



余談
個人の難易度表を作りました。
https://sugarbms.github.io/SUGARJOY/

