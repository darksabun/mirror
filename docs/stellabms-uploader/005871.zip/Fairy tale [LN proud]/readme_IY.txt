Fairy tale [LN proud]

BPM:68 推定難易度:◆12? NOTES:544 TOTAL:218(0.400%/N)

ズレ抜け多分無し

本体URL
　→https://drive.google.com/file/d/1tUR-V4wHBVCWm0yJs9zp19uEKbSvWOuy/view?usp=drive_link