なつまつり [life]

BPM:133 ガチ押し 推定難易度:st9 NOTES:3326 TOTAL:555

同梱譜面(natsumatsuri.bms)と比較してズレ抜け無し

本体URL
　→https://drive.google.com/file/d/1k-TGkwXfc4B8cARrKz1YBlsKNjMPCvk1/view?usp=drive_link