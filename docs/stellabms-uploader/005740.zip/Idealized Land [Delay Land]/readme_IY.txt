Idealized Land [Delay Land]

BPM:136 推定難易度:★★5 NOTES:2750 TOTAL:578

手動ディレイによる意図的なキー音の追加あり

同梱譜面(11_Idealized_Land_[N].bme)と比較して追加したキー音以外のズレ抜け無し

本体URL
　→http://mournfinale.com/bof2008/bmshq_idealizedland.rar