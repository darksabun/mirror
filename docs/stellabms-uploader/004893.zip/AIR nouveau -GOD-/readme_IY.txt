AIR nouveau -GOD-

BPM:165 推定難易度:st3 NOTES:2361 TOTAL:430

同梱譜面(litmus_airnouveau_02.bms)と比較してズレ抜け無し

本体URL
　→https://venue.bmssearch.net/bmstukuru2025/41