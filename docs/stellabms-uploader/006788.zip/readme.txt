[本体URL]
https://manbow.nothing.sh/event/event.cgi?action=More_def&num=72&event=149


[ズレ抜け]
同梱_Trusted Triangle__templateをベースに作成
下記の意図的な変更を除いてズレ抜け無し

・#WAVIAを63小節目1拍目→64小節目1拍目に移動


[NOTES / TOTAL]
1918 notes / 450 (0.235)


[雑記]
☆11の難配置を組み合わせて☆12にしようと思って作り始めた譜面
前半はまだその名残があるが後半は普通に☆12
同梱SPAと比べて、乱をかけて練習し甲斐のある譜面になるように配置した
★5くらい？