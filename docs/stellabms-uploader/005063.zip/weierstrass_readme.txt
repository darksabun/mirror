Song URL: https://manbow.nothing.sh/event/event.cgi?action=More_def&num=36&event=88
no misalignment with existsu_00temp.bms

exist Uniquely / Lipschitz / Weierstrass

Q:	为什么取 Weierstrass 作为假名？
A:	Weierstrass Function是一个的处处连续但处处不可微的函数，continues同时很“uniquely”

Q:	差分附带的Banner是？
A:	Weierstrass Function的图像，已经尽量尝试在300*80的分辨率里明显表示了。

Q:	这个谱面和Weierstrass Function有什么关系吗？
A:	实际上并没有，制作这个谱面的最初想法是[Uniformly]。
	但毕竟是假名活动，uniformly和Weierstrass Function甚至可以说冲突，所以最后选择空差分名

Q:	讲讲创作过程？
A:	纯粹以手感为前提，在全部的3-2-3-2段落里以16分位的8分锚键为线索进行排列。
	应该是我第一次尝试在排列里藏手感向的设计，算是近期新理解的一个总结。

Q:	为什么我觉得打起来比相同密度的乱打难一些？
A:	纯粹以手感为前提并不意味着这谱的手感顺手，因为这里的前提是我希望达到的手感而不是顺手。
	谱面的纵向密度其实不太均匀，同时三个主要段落的长度分别是16/16/12小节，对于玩家的稳定性和耐力都有所考研。
	
2025/01/26