st0? 朱獳 [耿山]
st4? 朱獳 [凶�]

本体URL
https://manbow.nothing.sh/event/event.cgi?action=More_def&num=481&event=146
