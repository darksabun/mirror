NightTheater [ミラノ風ドリア]

BPM:151 推定難易度:st6 NOTES:2744 TOTAL:467

意図的なキー音の追加や削除を含む差分なのでズレ抜けチェック不可

本体URL
　→https://manbow.nothing.sh/event/event.cgi?action=More_def&event=133&num=18