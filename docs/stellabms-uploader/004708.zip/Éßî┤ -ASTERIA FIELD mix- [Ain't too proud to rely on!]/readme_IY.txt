雪原 -ASTERIA FIELD mix- [Ain't too proud to rely on!]

BPM:178 乱打 推定難易度:st3 NOTES:3031 TOTAL:581

同梱譜面(_setsugen_r-7a.bme)と比較してズレ抜け無し

本体URL
　→http://web.archive.org/web/20170108135101/http://creation-records.info/bms/setsugen_r.rar