(st2?) 見送る一星、無我のソラ [WHITE OUT]

本体URL:https://venue.bmssearch.net/mutualfaith3/3

ズレ抜けについて
	同梱[ANOTHER](4_another.bms)とbms diff toolで比較して、ズレ抜けが無いことを確認しています。