本体:https://drive.google.com/uc?export=download&id=1G2rDSfJY_1SQ2YS30mLdbXP9LHkN5WkM
難易度:st4？
total:650
ズレ:手動ディレイによるズレあり
