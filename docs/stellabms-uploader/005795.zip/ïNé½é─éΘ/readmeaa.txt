原曲URL
https://manbow.nothing.sh/event/event.cgi?action=More_def&num=210&event=140

想定難易度 : st2
notes : 3000
total : 540
ズレチェック : st4の譜面

st4のOYASUMIMASTERの弱体化譜面です。st4基準なので本家譜面とズレチェックを行っておりません。
道中はst3相当だと思いますが、ラストはしっかり回復できるのでst2にしました。


