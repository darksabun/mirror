(st6?)
プレヤ [Sympathy]

本体URL:
https://manbow.nothing.sh/event/event.cgi?action=More_def&num=3&event=142

ズレ抜けについて
	意図的なキー音の追加あり
	同梱[SP ANOTHER](_q_prayer_04_SPA.bms)とAnzu BMS Diff Toolで比較して、キー音追加以外のズレ抜けなし
	bms diff toolで比較すると1つズレ抜けが検出されますが、これは小節長を変更した際に生じたものであり、実際のズレ抜けはありません