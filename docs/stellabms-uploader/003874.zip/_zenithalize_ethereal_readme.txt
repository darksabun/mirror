本体URL：http://mournfinale.com/bof2009/zenithalize.rar

アレンジ差分です。