Title: encounter [unreasonable]
BMS by 6yen: https://web.archive.org/web/20060621033435/http://www.commonsense.nu/songs/encounter.zip
Difficulty: FL8
BPM: 167
Comment: 

추가 키음을 전부 같은 폴더에 넣어주세요.
追加音源を全て同じフォルダに入れてください。

불합리함을 잘 견뎌보시기 바랍니다.
견뎌내어 리절트를 본다고 해도 행복할지는 잘 모르겠지만…