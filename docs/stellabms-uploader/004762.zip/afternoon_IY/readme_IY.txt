afternoon (J-HOUSE[過労死])

BPM:125 ガチ押し ズレ 推定難易度:st6 NOTES:3374 TOTAL:544

同梱譜面(afternoon_normal.bms)と比較してズレ抜け無し

本体URL
　→https://manbow.nothing.sh/event/event.cgi?action=More_def&num=420&event=133