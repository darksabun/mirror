本家URL
https://web.archive.org/web/20200107085506/http://grooverise.sakura.ne.jp/bms_game_coar_pkg/BMS%20Game%27s%20C&A%20Package.rar
(フォルダ名 : yuta_splatoon）

beatmaniaDP7段＆dp差分初作成＆テストプレイ無しで作成したので
愚譜面だと思いますが温かい目で見守ってください。
