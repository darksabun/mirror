_willed_empty.bmsと比較して一部ディレイ配置によるズレあり
本体:https://venue.bmssearch.net/bmstukuru2025/38