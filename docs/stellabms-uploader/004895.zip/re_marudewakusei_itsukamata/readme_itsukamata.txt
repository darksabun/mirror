追加キー音，無音あり．
同一定義のノートを削除しています．

本体URL
https://venue.bmssearch.net/bmstukuru2023/6

!!WARNING!!
これはBMSをたくさん作るぜ'23に登録された「まるで惑星の軌跡が交わるように（Reincarnation edit）」が本体です．
BOFXVの「まるで惑星の軌跡が交わるように」とは異なる楽曲なので注意！