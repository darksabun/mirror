Garnet Soul [Ain't too proud to rely on!]

BPM:154 推定難易度:st7 NOTES:2558 TOTAL:440

手動ディレイによるキー音の追加あり

同梱譜面(__Garnet Soul_N.bms)と比較して追加キー音以外のズレ抜け無し

本体URL
　→https://venue.bmssearch.net/bmstukuru2025/23