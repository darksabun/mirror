MooNatioN
287 a.k.a. EXAM.S
OBJ. Atharnal
本体 : https://manbow.nothing.sh/event/event.cgi?action=More_def&num=6&event=144
推定レベル：st2

Based on Nomal

ズレ チェック : SPN とズレ無し , 加速、停止ギミック修正されました。


よろしくお願いいたします。

-Atharnal (discord : Atharnal#2977)