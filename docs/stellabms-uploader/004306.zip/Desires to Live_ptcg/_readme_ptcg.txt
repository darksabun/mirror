(st5?) Desires to Live(ft.ANRI) [Overdrive]

本体:https://venue.bmssearch.net/tohobmsr/32

ズレ抜けについて
	意図的なキー音の追加があります。
	同梱[Another](7key_Another.bms)とbms diff toolで比較すると、ズレ抜けが無いことを確認しています。