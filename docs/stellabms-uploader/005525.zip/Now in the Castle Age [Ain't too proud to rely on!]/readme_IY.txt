Now in the Castle Age [Ain't too proud to rely on!]

BPM:144 推定難易度:st9 NOTES:3959 TOTAL:753

同梱譜面(_04_castleage-a.bms)と比較してズレ抜け無し

本体URL
　→https://manbow.nothing.sh/event/event.cgi?action=More_def&num=278&event=123