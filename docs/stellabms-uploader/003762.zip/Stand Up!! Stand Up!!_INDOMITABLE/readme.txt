Stand Up!! Stand Up!! [INDOMITABLE]
本体:https://venue.bmssearch.net/3/3

同梱[ANOTHER](_stst_4_ANOTHER.bms)とbms diff toolで比較して、ズレ抜け無し