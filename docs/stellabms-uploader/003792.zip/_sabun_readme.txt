「無垢」について (考えてみた)
p.p. / obj: Mary_Sue

本体：https://web.archive.org/web/20031208223309/http://popb.miyukinet.ne.jp/yosu/bms/process/muku.rar
推定レベル：★11-★12?

同梱innocence.bme基準、BGA改変によりズレ抜けが少しあります。
よろしくお願いいたします。

Mary_Sue (https://darksabun.github.io/Mary_Sue/ or @MarySue_BMS)
2024/03/28