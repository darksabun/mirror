(sl10,★17?) ラスティゲート [Nebula]

本体URL:
https://manbow.nothing.sh/event/event.cgi?action=More_def&event=116&num=52

[Another]と比較してズレ抜けなし

