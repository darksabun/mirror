同梱5KEY ANOTHERとズレなし。
楽曲：https://manbow.nothing.sh/event/event.cgi?action=More_def&num=82&event=144