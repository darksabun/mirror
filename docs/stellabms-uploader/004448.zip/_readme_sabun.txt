Ymphomania
暮狛 / Morph / obj: Mary_Sue

推定レベル：★23-24?
本体：https://morph-pack.netlify.app/

_base.bme基準、ギミック追加によってずれ抜け多数あり。
（同梱_readme.txt参考）
よろしくお願いいたします。

Mary_Sue (https://darksabun.github.io/Mary_Sue/ or @MarySue_BMS)
2024/10/15