reliance 
(sl11?) [trust]
(st5?) [rendance]

本体URL:
https://manbow.nothing.sh/event/event.cgi?action=More_def&num=72&event=137

ズレ抜けについて
	キー音の追加や意図的なアレンジを加えているためズレチェック不可
	同梱N譜面をベースに作成