Tramonto (SEA WIND[過酷])

BPM:134 推定難易度:st7 NOTES:3342 TOTAL:614

同梱譜面(_spn.bms)と比較してズレ抜け無し

本体URL
　→https://venue.bmssearch.net/bmsshuin2/32