DAYBREAK [FUTURE7]
本体: https://venue.bmssearch.net/genreshuffle4/80


ズレ抜けについて

	同梱[ANOTHER7](_daybreak_another7.bme)とbms diff toolで比較して、ズレ抜け無し
	ただしワープギミックを使用しているため、厳密には非常に僅かなズレがあります(意図したもの)
	上記の通り、bms diff toolのデフォルトの許容誤差1msの範囲ではズレがないことを確認していますが
	もし何か問題があれば連絡を頂ければ幸いです