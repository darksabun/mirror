Ammobium
(st4?) [Energize]
(st10?) [Regeneration]

本体URL:https://manbow.nothing.sh/event/event.cgi?action=More_def&num=4&event=146

ズレ抜けについて
	両差分とも、キー音の追加を除きズレ抜け無し
	同梱[SP ANOTHER](_ammobium_7_11_ANOTHER.bml)とbms diff toolで比較して、ズレ抜けが無いことを確認しています