https://manbow.nothing.sh/event/event.cgi?action=More_def&num=212&event=146

同梱 差分用/vectorize.bmx から作成
LN, ソフラン, 皿, 微縦, 物量の総合譜面
★19前後
LR2 MAX FIX使用可能