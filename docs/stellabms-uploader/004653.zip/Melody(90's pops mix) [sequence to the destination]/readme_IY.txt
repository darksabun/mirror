Melody(90's pops mix) [sequence to the destination]

BPM136 ガチ押し 推定難易度:st6 NOTES:3655 TOTAL:718

無音ノーツを使っています

同梱未配置(melody90s_plain.bms)と比較してズレ抜け無し

本体URL
　→https://manbow.nothing.sh/event/event.cgi?action=More_def&num=42&event=84