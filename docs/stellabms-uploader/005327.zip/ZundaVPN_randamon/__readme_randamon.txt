(st1?) ZundaVPN [RandaVPN]

本体URL:
https://k-bms.com/party_pabat/party.jsp?board_num=25&num=19&order=reg&odtype=a&ckattempt=1

ズレ抜けについて
	意図的なキー音の追加があります
	同梱ANOTHER譜面(litmus_zundavpn_04.bms)とbms diff toolで比較して、ズレ抜け無し