Title: 3.14 (TT mix) [JUST 8 PARTY]
Music: ルゼ
Object: A.K. as "0x00" respect Chneko

本体: https://www.luzeria.net/?p=387
差分: https://siro.dev/mirror/bms/ (314_8.zip)

Comment: 多分8ビットから問題ないよ :3

Extra Info:
동봉차분을 뒤늦게 발견했기 때문에, "yumether" 차분을 기반으로 하고있습니다.
즈레가 하나 있습니다만, 동봉 차분에서의 박자 자체가 어긋난것으로 보여 수정하였습니다.
#SCROLL을 사용합니다. LR2에서 플레이할수 없습니다.

同梱差分を遅く発見したため、"yumether"差分を基にしています。
スレが一つありますが、同梱差分の拍子自体がずれているようなので修正しました。
#SCROLLを使用します。 LR2でプレイできません。

Based on "yumether" chart, due to found bundled chart too late.
One note has wrong offset, moved due to bundled one seems very wrong.
Using #SCROLL, can't play on LR2.