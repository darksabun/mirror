Lazy days (House[過労死])

BPM131 ガチ押し/ズレ　推定難易度:st6～7 NOTES:3027 TOTAL:555

無音ノーツを使っています

同梱譜面(lazy_7a.bms)と比較してズレ抜け無し

本体URL
　→https://k-bms.com/party_pabat/party2015.jsp?board_num=15&num=18&order=reg&odtype=a