Summerland -LAST BOSS-

BPM:138 推定難易度:st9 NOTES:3440 TOTAL:654

意図的なキー音の追加や削除を含むアレンジ差分の為ズレ抜けチェック不可

本体URL
　→https://manbow.nothing.sh/event/event.cgi?action=More_def&num=76&event=71