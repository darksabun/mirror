(st6?) ラスティゲート [Irreplaceable Memory]

本体URL:
https://venue.bmssearch.net/bmstukuru2025/65

ズレ抜けについて
	同梱譜面とズレ抜け無し bms diff toolで[BEGINNER](___beginner.bms)と比較して確認