個人練習用譜面 st5-6?

Omino様譜面に倣って4-2と5-1乱打主体で作りました

後半から本番



本体url https://drive.google.com/drive/folders/1pJGq49KrF5St2Yfgp493oOKoDEIyZ6Hq

BMS Library　→ 漢字　→ 中途覚醒デイドリーム (by Sleepless feat.巡音ルカ／exemoss).rar