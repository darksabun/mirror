Verlesq ┌( )┘

BPM:280 推定難易度:★★5 NOTES:3285 TOTAL:592(0.180%/N)

曲改変あり

本体URL
　→https://venue.bmssearch.net/bmstukuru2023/2