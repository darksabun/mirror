Prominence (BMS Edit) [EXPLOSION]

BPM:150 推定難易度:st12 NOTES:3155 TOTAL:810

手動ディレイによるキー音の追加あり

同梱譜面(_spn.bms)と比較して追加したキー音以外のズレ抜け無し

本体URL
　→https://manbow.nothing.sh/event/event.cgi?action=More_def&num=193&event=140