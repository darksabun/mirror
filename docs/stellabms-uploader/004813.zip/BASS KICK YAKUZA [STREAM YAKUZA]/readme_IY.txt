BASS KICK YAKUZA [STREAM YAKUZA]

BPM:200 乱打 推定難易度:st7 NOTES:4220 TOTAL:888

同梱譜面(_n.bms)と比較してズレ抜け無し

本体URL
　→https://manbow.nothing.sh/event/event.cgi?action=More_def&num=66&event=137