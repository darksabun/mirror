星月トラジコメディー [Ain't too proud to rely on!]

BPM:155	乱打 微縦連 推定難易度:st7 NOTES:3054 TOTAL:592

同梱譜面(_7n.bms)と比較してズレ抜け無し

本体URL
　→https://venue.bmssearch.net/tohobmsr/27