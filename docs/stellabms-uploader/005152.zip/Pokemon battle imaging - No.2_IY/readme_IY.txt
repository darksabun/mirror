Pokemon battle imaging - No.2 [モンスターボール級]

BPM:222 推定難易度:st2 NOTES:2542 TOTAL:534

Pokemon battle imaging - No.2 [スーパーボール級]

BPM:222 推定難易度:st5 NOTES:2852 TOTAL:599

Pokemon battle imaging - No.2 [ハイパーボール級]

BPM:222 推定難易度:st7 NOTES:3364 TOTAL:791

Pokemon battle imaging - No.2 [マスターボール級]

BPM:222 推定難易度:st9 NOTES:3570 TOTAL:678



キー音の追加や意図的なキー音の削除を含む差分の為ズレ抜けチェック不可

本体URL
　→https://cerebralmuddystream.nekokan.dyndns.info/betoo/index.php?mode=datail&no=41