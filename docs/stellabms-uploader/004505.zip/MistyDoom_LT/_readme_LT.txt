URL: https://manbow.nothing.sh/event/event.cgi?action=More_def&num=282&event=146
Difficulty: st4
No misalignments compared to _temp.xxx.

BOF:TT差分企画: https://darksabun.github.io/event/boftt/