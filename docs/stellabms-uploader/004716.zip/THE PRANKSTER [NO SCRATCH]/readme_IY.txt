THE PRANKSTER [NO SCRATCH]

BPM:136 ガチ押し 推定難易度:st4 NOTES:2716 TOTAL:518

同梱譜面(THE_PRANKSTER_n.bms)と比較してズレ抜け無し

本体URL
　→https://venue.bmssearch.net/bmsshuin2/81