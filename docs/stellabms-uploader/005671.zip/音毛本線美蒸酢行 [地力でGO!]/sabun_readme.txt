音毛本線美蒸酢行 [地力でGO!]

本体URL:https://manbow.nothing.sh/event/event.cgi?action=More_def&num=46&event=147
同梱_frs1bimusu_7ANOTHER.bmsとズレ抜け無し。

sl6 ★10？