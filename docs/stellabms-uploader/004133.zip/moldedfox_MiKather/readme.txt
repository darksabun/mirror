同梱　https://manbow.nothing.sh/event/event.cgi?action=More_def&num=15&event=144

同梱未配置ファイルとズレ抜け無し。