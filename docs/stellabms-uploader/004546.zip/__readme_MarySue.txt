Eraser / Echa - GEHENNA [TU9MT0NI]

本体：https://manbow.nothing.sh/event/event.cgi?action=More_def&num=157&event=146
推定レベル：★24-25?

__GEHENNA-temp基準、ソフラン関連のずれ抜けいくつかあり。
よろしくお願いします。

Mary_Sue (https://darksabun.github.io/Mary_Sue/ or @MarySue_BMS)
2024/11/02