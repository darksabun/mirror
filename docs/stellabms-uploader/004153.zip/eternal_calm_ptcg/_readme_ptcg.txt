Eternal calm [DOMO MASTER]

本体URL:https://manbow.nothing.sh/event/event.cgi?action=More_def&num=431&event=140

ズレ抜けについて
	同梱[EASY7](_eternal_calm_easy7.bme)と、bms diff toolにてズレ抜けが無いことを確認しています。