st1? Neo Side [Run Away]

Harunao, Kanna obj:E BGI: LiZiO

後半をカットしたことによるズレ抜けあり。

本体URL
https://manbow.nothing.sh/event/event.cgi?action=More_def&num=332&event=140