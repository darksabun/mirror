[本体URL]
https://venue.bmssearch.net/bmstukuru2025/2

[BPM]
MAIN-BPM : 200
MIN-BPM ; 133.33

[ズレ抜け]
0_Checkena.hinagataをベースに作成
ズレは全て意図的なもの（3連符が192分ズレしているものについて再配置）

[配置リファレンス]
m1dy Deluxe / m1dy