LIGHTNING STAIRWAY [Ain't too proud to rely on!]

BPM:148 推定難易度:★★5 NOTES:2419 TOTAL:484(0.200%/N)

本体URL
　→https://manbow.nothing.sh/event/event.cgi?action=More_def&event=104&num=268