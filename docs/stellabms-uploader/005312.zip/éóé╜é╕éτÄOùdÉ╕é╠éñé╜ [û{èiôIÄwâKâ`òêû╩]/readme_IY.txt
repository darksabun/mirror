いたずら三妖精のうた [本格的指ガチ譜面]

BPM:160 推定難易度:★★4 NOTES:3838 TOTAL:730

キー音の追加あり

同梱譜面(threefairies[7B].bms)と比較して追加したキー音以外のズレ抜け無し

本体URL
　→https://venue.bmssearch.net/tohobmsr/18