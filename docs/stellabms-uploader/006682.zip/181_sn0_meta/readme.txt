[本体URL]
https://manbow.nothing.sh/event/event.cgi?action=More_def&num=181&event=149

[ズレ抜け]
同梱ZERO.(bms)及びZERO_7A.bmsとズレ抜け無し(Anzu BMS Diff Tool)

[NOTES / TOTAL]
2500 notes / 666 (0.266)

[BPM]
200 - 2000000200
use MIN-FIX (LR2) / MAIN-BPM (oraja)

[雑記]
LUSTFULな譜面を作ろうとしたらこうなった

[譜面リファレンス]
Aleph-0 [INSANE] / LeaF
Alcubierre Drive [INSANE] / raii, SANY
特にこの記事を大いに参考にしました https://raii-x.hatenablog.com/entry/2018/04/28/025006