(st4?) Childie Sharp [Turbocharged]

本体URL:
https://colosseo.nekokan.dyndns.info/c02_shuffle/detail.php?n=41

ズレ抜けについて
	手動ディレイなどによる意図的なキー音の追加あり
	同梱Another譜面(_A.bms)とbms diff toolで比較して、ズレ抜け無し