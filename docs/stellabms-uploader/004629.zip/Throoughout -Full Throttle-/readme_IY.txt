Throoughout -Full Throttle-

BPM175 乱打/微縦連 推定難易度:st7 NOTES:3987 TOTAL:777

無音ノーツを使っています

同梱譜面(_Throoughout_Beginner.bms)と比較してズレ抜け無し

本体URL
　→https://manbow.nothing.sh/event/event.cgi?action=More_def&num=69&event=135