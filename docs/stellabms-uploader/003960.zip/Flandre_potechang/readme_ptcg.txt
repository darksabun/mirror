Flandre, sister of insanity [7key Cranberry]

本体:http://onedrive.live.com/?cid=6FFE918F74B836BD&id=6FFE918F74B836BD%21175


同梱[7key ANOTHER]とbms diff toolで比較して、ズレ抜け無し