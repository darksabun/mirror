reverieland -reincarnation-

BPM:142 推定難易度:st9 NOTES:3400 TOTAL:646

同梱されているwavファイルも導入してください

手動ディレイによるキー音の追加や意図的なキー音の削除、キー音をカットして再配置していたりするのでズレ抜けチェック不可能
一応同梱譜面(24-reverieland-7Another.bme)と比較して意図的に消したキー音以外のズレ抜けは無し

本体URL
　→https://manbow.nothing.sh/event/event.cgi?action=More_def&event=120&num=32