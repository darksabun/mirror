EUROBEATアイドル橘花音のテーマ [Ain't too proud to rely on!]

BPM:156 推定難易度:st7 NOTES:3835 TOTAL:729

同梱譜面(_A.bms)と比較してズレ抜け無し

本体URL
　→https://manbow.nothing.sh/event/event.cgi?action=More_def&num=87&event=110