U/I [MAGE]
本体:https://venue.bmssearch.net/genreshuffle4/10

同梱NORMAL(U_I_N.bms)とbms diff toolで比較して、ズレ抜けがないことを確認しています。