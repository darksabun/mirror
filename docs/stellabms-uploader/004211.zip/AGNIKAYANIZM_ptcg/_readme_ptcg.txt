AGNIKAYANIZM [FORBIDDEN RITUAL]

本体:https://manbow.nothing.sh/event/event.cgi?action=More_def&num=371&event=133

ズレ抜けについて
	手動ディレイによるキー音追加のため厳密なズレチェック不可
	bms diff toolにて同梱[Insane](AGNIKAYANIZM_INSINE.bms)と比較して、ズレ抜け無し