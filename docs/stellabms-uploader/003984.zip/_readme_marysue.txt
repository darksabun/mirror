Enchanted Maze <SP ARCANE>
Kalse OBJ:Mary_Sue / BGI:織部よよ

本体：https://manbow.nothing.sh/event/event.cgi?action=More_def&num=59&event=144
推定レベル：★22

_EnchantedMaze(0noteファイル)とズレ抜けなし。
よろしくお願いいたします。

Mary_Sue (https://darksabun.github.io/Mary_Sue/ or @MarySue_BMS)
2024/05/21