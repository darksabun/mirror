st2? [Re]Creation [Reincarnation]
st12? [Re]Creation [Finale]

LucaProject obj:E

本体URL
https://manbow.nothing.sh/event/event.cgi?action=More_def&num=346&event=149
