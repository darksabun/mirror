Gollimly Rosy

BPM:130 推定難易度:st8 NOTES:3222 TOTAL:527

同梱譜面(Trimly Rosy [Another].bms)と比較してズレ抜け無し

本体URL(保管)
　→https://drive.google.com/file/d/1X4KP9Wr8qL36d8rd6rqponYRo0vnmlc2/view?usp=drive_link