st4? E.V.E.R [Alternate World]
st8? E.V.E.R [Alternate World EX]

SOMON obj&arr:Stellaおばさん

曲改変あり。
追加音源を含みます。BMS本体と同じフォルダに格納してください。
差分作成用にBass譜面を同梱しています。

曲改変のためズレチェック不可。

本体URL
https://manbow.nothing.sh/event/event.cgi?action=More_def&num=445&event=146