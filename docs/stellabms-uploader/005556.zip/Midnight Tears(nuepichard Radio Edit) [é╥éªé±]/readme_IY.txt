Midnight Tears(nuepic*hard Radio Edit) [ぴえん]

BPM:140 推定難易度:st9 NOTES:2461 TOTAL:468

意図的なキー音の追加や削除を含むアレンジ差分の為ズレ抜けチェック不可

本体URL
　→https://drive.google.com/file/d/1IGEyrE7C3bgtY2Z3CbXJQlWibmNRpLLQ/view?usp=drive_link