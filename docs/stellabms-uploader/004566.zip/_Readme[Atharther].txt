超度 -Go Beyond-
Daily天利 (movie : 小鹏xpeng / Illust: Viosgit)
OBJ. Atharnal
本体 : https://manbow.nothing.sh/event/event.cgi?action=More_def&num=105&event=142
推定レベル：St4~5?

ズレ チェック : ディレイキー音ありによるズレあり


24番目の差分。
よろしくお願いいたします。

-Atharnal (discord : Atharnal#2977)