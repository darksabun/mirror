本体:https://manbow.nothing.sh/event/event.cgi?action=More_def&event=110&num=536
微アレンジズレ有