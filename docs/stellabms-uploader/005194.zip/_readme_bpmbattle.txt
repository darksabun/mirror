Gear!!!!!!!!!!!!!!!!!!!!!!!!! for BPM BATTLE 2025
削除 / obj: Mary_Sue

本体：https://archive.org/download/sakuzyo_bms/Sakuzyo_%E5%89%8A%E9%99%A4_bms_collection.rar/Sakuzyo_%E5%89%8A%E9%99%A4_bms_collection%2FGear_rr6.rar

推定レベル：★★5?

同梱gear16000.bms基準ずれ抜けなし

Comment : F A S T E R 