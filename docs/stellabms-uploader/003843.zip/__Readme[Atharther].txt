Endemize
Music: あとぅす feat.つゆり花鈴(mov:りーふぱいザウルス)
OBJ. Atharnal
本体 : https://manbow.nothing.sh/event/event.cgi?action=More_def&num=38&event=137
推定レベル：sl8~9?

ズレ チェック :  ___normal.bms とズレなし


39番目の差分。
よろしくお願いいたします。

フィードバックをお願いします。

-Atharnal (discord : Atharnal#2977)
-Twitter : https://twitter.com/atharnal