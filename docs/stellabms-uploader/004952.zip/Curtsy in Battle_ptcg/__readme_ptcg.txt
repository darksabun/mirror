(st3?) Curtsy in Battle [LUNATIC]

本体URL:
https://venue.bmssearch.net/tohobmsr/43

ズレ抜けについて
	意図的なキー音の追加があります
	同梱[SP HYPER](Curtsy_in_Battle_SPH.bms)とbms diff toolで比較して、ズレ抜け無し