Ignited Time (Evil7)

BPM:144 推定難易度:★★5 NOTES:2740 TOTAL:521

同梱譜面(_Ignited Time [Beginner7].bme)と比較してズレ抜け無し

本体URL
　→https://drive.google.com/file/d/1HWfQku7fKjb4qlesEqCOi5L3teSWRhZh/view?usp=drive_link