Fuzzy-Navel [Alcoholic]

BPM:141 推定難易度:st8 NOTES:2846 TOTAL:570

同梱未配置(_mihaichi.xxx)と比較してズレ抜け無し

本体URL
　→https://manbow.nothing.sh/event/event.cgi?action=More_def&num=13&event=137