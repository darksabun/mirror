st1? Indira[EX]

本体URL
https://k-bms.com/party_pabat/party.jsp?board_num=24&num=1&order=reg&odtype=a

SP_A.bmsと比較してズレ抜けなし