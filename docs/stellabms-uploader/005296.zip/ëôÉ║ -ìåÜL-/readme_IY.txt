遠声 -号哭-

BPM:185 推定難易度:st10 NOTES:3246 TOTAL:763

同梱未配置(toogoe_mihaichi)と比較してズレ抜け無し

本体URL
　→https://yaritaihoudie.fr/bumusu.html


※ BMS作者のHPに以下の記載があるため、該当する難易度表への提案は禁止です。

差分譜面か同梱譜面かを問わず、このページから配布されている作品の譜面を
Stella, Satellite, EXOPLANET, Overjoy, NEW GENERATION
に提案することを禁止しています。

サイト移行のお知らせなどが発表されずにこのページがなくなる場合（本サイトが閉鎖してIAでしか閲覧できなくなるとか）、上記の内容は無効になります。