st6? しんきろうのビーチ [DOMO MASTER]

Yosk! (原曲:石川淳) obj:E

「_hirobiro_SPX.bme」と比較してズレ抜け無し

本体URL
https://manbow.nothing.sh/event/event.cgi?action=More_def&num=251&event=142