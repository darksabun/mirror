DP★7 ロリキート [Colorful]

BMS URL (Archive)
https://mega.nz/folder/FNFDCQaT#wfv-iI4UuSIaGpP0oFZdtQ/file/EZdyQJpC

No Misalignment (Based on Lorikeet_SPA.bml)