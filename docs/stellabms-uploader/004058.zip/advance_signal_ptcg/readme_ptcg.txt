アドバンス・シグナル [RESISTANCE]

本体:https://manbow.nothing.sh/event/event.cgi?action=More_def&num=34&event=142

ズレ抜けについて
	同梱[NORMAL](2_normal.bms)とbms diff toolで比較して、ズレ抜け無し。(許容誤差1ms)
	37小節のギミックのため厳密にはこれ以降ズレがありますが、意図的なものです。