本体URL:https://manbow.nothing.sh/event/event.cgi?action=More_def&num=45&event=135
TeravoltA.bmsとズレ抜け無し。無音ノーツあり。

難易度:★9～★10(sl5～sl6)