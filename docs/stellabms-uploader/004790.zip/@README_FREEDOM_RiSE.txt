�����e�B�A�����G�N�X�v���[���[[FREEDOM R��SE]
�{��URL: http://manbow.nothing.sh/event/event.cgi?action=More_def&num=87&event=132

Except the changes in BPM(200.00��222.22) and the accelerated BG sounds & BGA("_backx_.ogg"��"_backx_bpm222.ogg"(x=1,2,3,4,KeyOut),"_bga.wmv"��"_bga_bpm222.wmv"),
there are no other misalignment according to AnzuBMSDiff


Due to the 5MB limit of the uploader, I can't upload the accelerated BGA together, but you can acquire it as follows

1. Download FFmpeg here: https://www.gyan.dev/ffmpeg/builds/ffmpeg-git-essentials.7z
2. Copy the ffmpeg.exe to the bms folder of the song �t�����e�B�A�����G�N�X�v���[���[
3. Shift+right click the blank space of the folder, run Powershell, and type the following command:

	ffmpeg -i _bga.wmv -filter:v "setpts=0.900009*PTS" -b:v 1200k _bga_bpm222.wmv
	
	//explanatory note:
	//0.900009=200/222.22(original BPM/new BPM)
	//1200k meaning the bitrate of "_bga_bpm222.wmv" will be 1200kbps

Btw, you can accelerate(or decelerate) an audio file WITHOUT CHANGING ITS TUNE by the following command:

	ffmpeg -i _back1_.ogg -filter:a "rubberband=tempo=1.1111" _back1_bpm222.ogg
	
	//explanatory note:
	//1.1111=222.22/200(new BPM/original BPM)

Thanks for playing!