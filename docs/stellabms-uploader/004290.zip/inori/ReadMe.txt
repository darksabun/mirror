Event: BOF2004
URL: https://drive.google.com/file/d/13SjQElE2Pg5fxuiU53uGuE87JWXie49W/view?usp=sharing

Respect for -Tear-.

The solitary angel simply continues to pray silently.
Even if it will not be rewarded forever.