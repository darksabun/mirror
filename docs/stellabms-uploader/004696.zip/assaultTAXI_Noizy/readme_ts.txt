本体:https://manbow.nothing.sh/event/event.cgi?action=More_def&num=214&event=142
音源の再配置+開始地点を0小節から1小節目に変更したことにより全体にズレあります