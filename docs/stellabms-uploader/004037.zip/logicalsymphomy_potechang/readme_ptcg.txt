LOGICAL SYMPHONY [Distorted Melody]

本体:https://manbow.nothing.sh/event/event.cgi?action=More_def&num=340&event=133

同梱ANOTHER(_A.bms)とbms diff toolで比較して、ズレ抜け無し