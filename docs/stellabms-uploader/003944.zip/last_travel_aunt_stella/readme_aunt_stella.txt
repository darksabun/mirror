st2? Last Travel [Flight 2908.04.13]

AuroD & wheatfox obj:Stellaおばさん

last_travel_flight1970.bmsと比較してズレ抜けなし

本体URL
https://manbow.nothing.sh/event/event.cgi?action=More_def&num=298&event=140

