(st5?) Lucid Dreaming [Subconscious]

本体URL:
https://manbow.nothing.sh/event/event.cgi?action=More_def&num=144&event=88

ズレ抜けについて
	意図的なキー音の追加があります
	同梱[ANOTHER](lucid_dreaming_A.bms)とbms diff toolで比較して、ズレ抜け無し