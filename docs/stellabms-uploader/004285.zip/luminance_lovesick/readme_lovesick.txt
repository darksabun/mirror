st2? Luminance [Lovesick]

JUDGE EASY　
TOTAL 637.3

litmus* ft. 橘ルミ obj:EGRET.

本体URL
https://9domu46i.com/yuruyuru/phase21.html

同梱「litmus_luminance_04_SPA.bms」と比較してズレ抜け無し（AnzuBMSDiffで確認）