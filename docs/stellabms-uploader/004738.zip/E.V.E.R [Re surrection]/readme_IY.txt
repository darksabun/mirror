E.V.E.R [Re:surrection]

BPM:186 乱打 ズレ 推定難易度:st6 NOTES:4062 TOTAL:816

Stellaおばさんの曲改変差分(upload/4734)を元に作成
追加音源を含みます、追加音源はStellaおばさんの差分ファイルに同梱されています

曲改変差分のためズレ抜けチェック不可

本体URL
　→https://manbow.nothing.sh/event/event.cgi?action=More_def&num=445&event=146

Stellaおばさんの差分
　→https://stellabms.xyz/upload/4734