海神奇譚 [泡沫]

追加音源があるので必ずこちらも導入してください:

https://drive.usercontent.google.com/uc?id=15gZRIoqGLdm3Of9-DTDWuY3KaAdqKMHZ&export=download