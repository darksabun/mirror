某凄い人のS乱エクハ見てたらなんかここまでやってもいいかなって
Figmentは人向けのst7ですけどMoonstruckは人外向けです
あんまり新しくLN追加したことなかったので試験的に入れてみましたがどうでしょうか

本体:http://leafbms.web.fc2.com/song.html

_H7.bmsと比較してズレはありません。