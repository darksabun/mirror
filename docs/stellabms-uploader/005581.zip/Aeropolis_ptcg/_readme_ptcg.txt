(st4?)
Aeropolis [Intense]

本体URL:
https://manbow.nothing.sh/event/event.cgi?action=More_def&num=33&event=147

ズレ抜けについて
	意図的なキー音の追加あり
	同梱[SP MULTIPLEX](_Aeropolis_vvv_06_SPMultiplex.bms)とbms diff toolで比較して、ズレ抜け無し