本体:http://web.archive.org/web/20141028134007/http://plugout4.com/plugout/ATM[vol.1].zip
(直リンク＆パッケージ注意、中の"6_frol_beaker_(hq)"が本体です。)
難易度:	★★5？
total:777
ズレ:手動ディレイによるズレあり
