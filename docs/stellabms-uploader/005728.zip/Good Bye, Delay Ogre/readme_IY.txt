Good Bye, Delay Ogre

BPM:144 推定難易度:★★5 NOTES:3575 TOTAL:715

手動ディレイによる意図的なキー音の追加あり

同梱譜面(073_ogre_7a)と比較して追加したキー音以外のズレ抜け無し

本体URL
　→https://drive.google.com/file/d/1DMvbmhAluthzKV9WYaAevKteFNscUvx9/view?usp=drive_link