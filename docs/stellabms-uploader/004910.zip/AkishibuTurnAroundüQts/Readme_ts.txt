本体:https://venue.bmssearch.net/letsbmsedit3/2
曲改変によるズレあり