GHOST IN THE DEEP ABYSS [Creepy]

BPM:200 推定難易度:★★5 NOTES:4106 TOTAL:945

意図的なキー音の追加や削除を含むアレンジ差分なのでズレ抜けチェック不可

本体URL
　→https://manbow.nothing.sh/event/event.cgi?action=More_def&num=156&event=140