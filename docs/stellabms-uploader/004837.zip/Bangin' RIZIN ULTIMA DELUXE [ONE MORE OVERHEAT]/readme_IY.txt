Bangin' RIZIN ULTIMA DELUXE [ONE MORE OVERHEAT]

BPM:207 乱打 皿複合 微縦連 推定難易度:st7 NOTES:3048 TOTAL:707

キー音の追加あり

同梱譜面(_banginrizin_NORMAL.bme)と比較して追加キー音以外のズレ抜け無し

本体URL
　→https://manbow.nothing.sh/event/event.cgi?action=More_def&num=413&event=137