st1? R.I.P My Pudding! [フィジカル横プリン式]

本体URL
https://manbow.nothing.sh/event/event.cgi?action=More_def&num=8&event=144

SP_kusodeka.bmsと比較して10小節目に意図的な抜けノーツあり
以下は全て意図的な抜けノーツです

******** difference check ********
bar	position	wavid
#010 11	(13 / 16)	#WAV04 is missing in X. (b_hat_v76l16o3g.wav)
#010 19	(13 / 16)	#WAV03 is missing in X. (b_snare_v102l16o3d.wav)
#010 13	(7 / 8)	#WAV05 is missing in X. (b_hat_v89l16o3g.wav)
#010 15	(7 / 8)	#WAV03 is missing in X. (b_snare_v102l16o3d.wav)
#010 12	(15 / 16)	#WAV04 is missing in X. (b_hat_v76l16o3g.wav)
#010 18	(15 / 16)	#WAV03 is missing in X. (b_snare_v102l16o3d.wav)