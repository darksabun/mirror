Aerialwalker [Ain't too proud to rely on!]

BPM:128 ガチ押し ズレ 推定難易度:st5 NOTES:3014 TOTAL:514

同梱されているwavも本体に入れてください

LR2IR登録の為にBGMファイル(00-bg.wav)を4つに切り分けているのでズレチェック不可
一応同梱譜面(Aerialwalker_7A.bme)と比較してBGMファイルを消した以外のズレ抜けは無し

本体URL
　→https://drive.google.com/file/d/1kHkezqKRZzgvcvSo-_PTLqiPVv38nudM/view?usp=drive_link