ZundaVPN [RendaVPN]

BPM:165 推定難易度:st6 NOTES:3151 TOTAL:678

キー音の追加あり

同梱譜面(litmus_zundavpn_04.bms)と比較して追加したキー音以外のズレ抜け無し

本体URL
　→https://k-bms.com/party_pabat/party.jsp?board_num=25&num=19&order=reg&odtype=a