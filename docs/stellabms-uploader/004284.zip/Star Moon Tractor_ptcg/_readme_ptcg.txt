(st4?) 星月トラジコメディー [GALAXY]

本体:https://venue.bmssearch.net/tohobmsr/27

ズレ抜けについて
	同梱another(_7a.bms)とbms diff toolで比較して、ズレ抜け無し
	意図的なキー音の追加があります