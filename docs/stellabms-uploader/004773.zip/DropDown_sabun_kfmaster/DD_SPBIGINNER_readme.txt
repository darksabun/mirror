BMS DL : https://drive.google.com/file/d/0ByqbsLkBAnPlVFJYeWZLZEpWUm8/view?usp=sharing&resourcekey=0-M4-d0QU9FTWQWWJ-KYZZXg

공패턴 파일인 DD.bms와 비교하여 즈레가 없는 걸 확인함.

DD.bms（未配置）と比較してズレないことを確認しました。