今の日本には高難易度が足りない！
王道ガチ押しです。


___INSANE.bmsとズレ無し。
本体:https://venue.bmssearch.net/hanadayori/21
