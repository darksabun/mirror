☆10? Save The Night [gm+]
Notes : 800
Total : 400

かなり久しぶりのギミック譜面です。遊びやすさを意識して作りました。
演出の都合上所々覚えないと厳しい箇所はありますが、最低限の暗記で済むよ配慮はしたつもりです。
素晴らしい曲・BGAと共に楽しんでいただけたら嬉しいです。

[参考にしたギミック譜面]
本差分は色々なギミック譜面を参考に...もといパクってきています。
どれも素晴らしいギミック差分なので是非触れてみてください。

Rush-Hour [For Mr.NMT]
2:00～ 放物線っぽい具現化
https://www.youtube.com/watch?v=0UxPsNWQnJc

The NightScape [gm+]
2:01～ 小節線を用いた予告
https://www.youtube.com/watch?v=kKIgiSfvGrY

WILDANCE [ET Mode] 
8分で叩くとドゥンドゥン生えてくるやつ
https://www.youtube.com/watch?v=0au2vmnZvKk

Lyrith -迷宮リリス- -smyre-
1:13～ STOP制御を用いた小節線が伸び縮みするギミック
https://www.youtube.com/watch?v=J7Q0zI8y-7A

さよならコスモノート [カオスノート]
0:15～ 小節線逆走＋地雷予告
https://www.youtube.com/watch?v=y0fq92IO6U8
