本家URL
https://manbow.nothing.sh/event/event.cgi?action=More_def&num=14&event=49

想定難易度★23
notes : 3600
TOTAL値 : 648
ズレチェック：不可能

ターン制バトルBMSです。英語ではTurn-based battleと呼ばれるらしいので差分名をTBBにしました。