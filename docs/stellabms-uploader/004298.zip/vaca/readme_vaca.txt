★★4? BATHALA [vaca]

アレンジ箇所ありのためズレチェック不可。

本体URL
http://manbow.nothing.sh/event/event.cgi?action=More_def&num=64&event=133