endemize [Desired Ending]

本体:https://manbow.nothing.sh/event/event.cgi?action=More_def&num=38&event=137

同梱[BEGINNER](___beginner.bms)とbms diff toolで比較して、ズレ抜け無し