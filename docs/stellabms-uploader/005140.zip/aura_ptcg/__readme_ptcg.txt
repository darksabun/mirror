(st3?) aura [Catastrophe]

本体URL:
https://manbow.nothing.sh/event/event.cgi?action=More_def&num=10&event=88

ズレ抜けについて
	手動ディレイによるキー音の追加・削除による軽めの曲改変あり
	同梱[Another](aura_A.bml)をベースに作成しており、bms diff toolで比較して検出される5つのズレは全て意図的であることを確認しています