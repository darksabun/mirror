はなびのうた [ふつう]

BPM:138 推定難易度:st5 NOTES:3478 TOTAL:631

同梱譜面(_another.bms)と比較してズレ抜け無し

本体URL
　→https://manbow.nothing.sh/event/event.cgi?action=More_def&num=325&event=146