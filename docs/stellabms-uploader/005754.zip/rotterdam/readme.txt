本体:https://manbow.nothing.sh/event/event.cgi?action=More_def&num=440&event=137
難易度:	st5？
total:700

休憩少なめの体力譜面です。st4かも？
