Mr.Belligerent King [Ain't too proud to rely on!]

BPM:230 推定難易度:st9 NOTES:4300 TOTAL:1018

追加キー音あり

同梱譜面(01.bme)と比較して追加キー音以外のズレ抜け無し

本体URL
　→https://cerebralmuddystream.nekokan.dyndns.info/betoo/?mode=datail&no=27