I find this song by chance and then had the idea of making a CHABUN for it. So I cut the bass more precisely and added the note to the sheet music, and made the "min" CHABUN. I originally had the idea of making a "MAX" CHABUN, but there were too few usable notes and it was hard to arrange, so I gave up.
--------------------

# ISO[min] by czszzh
## sl2?
- 1315 notes
- 330 total
- 13.74 notes / sec (AVG)
- 22 notes / sec (MAX)