Twilight [Solid Stream]

BPM:172 乱打 推定難易度:st5 NOTES:3139 TOTAL:538

同梱譜面(score_seven_normal.bml)と比較してズレ抜け無し

本体URL
　→https://manbow.nothing.sh/event/event.cgi?action=More_def&num=17&event=67