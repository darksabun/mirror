アドバンス・シグナル [この番組は、ご覧のスポンサーの提供でお送りします。]

BPM192 乱打/多要素 推定難易度:st5 NOTES:3028 TOTAL:485

無音ノーツをまあまあ使っています

同梱譜面(4_another.bms)と比較してズレ抜け無し

本体URL
　→https://manbow.nothing.sh/event/event.cgi?action=More_def&num=34&event=142