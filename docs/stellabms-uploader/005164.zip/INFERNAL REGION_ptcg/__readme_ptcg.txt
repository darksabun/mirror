INFERNAL REGION 
(st6?) [Intense]
(st8?) [Immortal]

本体URL:
https://venue.bmssearch.net/tohobmsr/23

ズレ抜けについて
	両差分とも意図的なキー音の追加あり
	同梱[ANOTHER](_infernal_another.bms)とbms diff toolで比較して、ズレ抜け無し