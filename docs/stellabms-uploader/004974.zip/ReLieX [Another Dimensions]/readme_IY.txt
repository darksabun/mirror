ReLieX [Another Dimensions]

BPM:206 推定難易度:st7 NOTES:2926 TOTAL:527

NORMAL,HARD判定版とbaseファイルもあります

同梱されているoggファイルも一緒に導入してください

曲改変差分の為ズレ抜けチェック不可

本体URL
　→https://manbow.nothing.sh/event/event.cgi?action=More_def&event=116&num=306