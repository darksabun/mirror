原曲URL
https://venue.bmssearch.net/tohobmsr/18

想定難易度★21
notes : 3050
TOTAL値 : 549

本家sph譜面とズレチェック済み

ネタ2割、地力8割ぐらいの同時押し譜面
stella差分アップローダは5MBを超える容量は投稿できないらしいので、ムービーを付けたい方は下記のURLから落として入れてください
https://drive.google.com/file/d/196Bd6exYFmVJiIcdLizH5Tn2lke5DPab/view?usp=sharing
