st2? Echo [Enter]
st5? Echo [Esc]

wheatfox bga:wheatfox obj:E

�{��URL
https://manbow.nothing.sh/event/event.cgi?action=More_def&num=84&event=140
