ユアンシェンは俺たちに連打を伝えたかったのか

BPM:180 推定難易度:st5 NOTES:3510 TOTAL:667

同梱未配置(__________差分用.sabun)と比較してズレ抜け無し

本体URL
　→https://manbow.nothing.sh/event/event.cgi?action=More_def&num=15&event=129