本体:https://mega.nz/folder/BDJAhJDJ#BrSjRbk10U_uFphI7JG_xg/file/cfxA3TDC
難易度:st7?
total:555
ズレ:全体通して意図的なズレがあります