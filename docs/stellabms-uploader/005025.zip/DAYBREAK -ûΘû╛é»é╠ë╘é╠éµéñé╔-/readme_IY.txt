DAYBREAK -夜明けの花のように-

BPM:170 推定難易度:st6 NOTES:3330 TOTAL:668

手動ディレイによる追加キー音あり

同梱譜面(_daybreak_another7.bme)と比較して追加したキー音以外のズレ抜け無し

本体URL
　→https://venue.bmssearch.net/genreshuffle4/80