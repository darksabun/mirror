ABYSSAL // COSMOS 
(st6?) [PROUD // INTENSITY]
(★★6?) [PROUD // INTENSITY+]

本体URL:
https://manbow.nothing.sh/event/event.cgi?action=More_def&num=16&event=146

ズレ抜けについて
	両差分とも、意図的なキー音の追加があります
	bms diff toolで同梱[SP Another](AbyssalCosmos_Another.bms)と比較して検出される5つのズレは、ソフラン削除によるもので意図的です