神と繭の狂詩曲 [SP METAMORPHOSIS]
RB.H × 10lulu × Sennzai / mov: D・ENNY illust: Silufer α bms: RB.H obj: Mary_Sue

本体：https://manbow.nothing.sh/event/event.cgi?action=More_def&num=59&event=146
推定レベル：★23-24

_mayu_empty.bms基準ズレ抜けなし。
よろしくお願いいたします。

Mary_Sue (https://darksabun.github.io/Mary_Sue/ or @MarySue_BMS)
2024/10/26