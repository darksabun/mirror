Anthemizer [Delayzer]

BPM:148 推定難易度:★★5 NOTES:2108 TOTAL:485

手動ディレイによる意図的なキー音の追加あり

同梱譜面(0.gyanubasu_7n.bms)と比較して追加したキー音以外のズレ抜け無し

本体URL
　→https://drive.google.com/file/d/1Xj_n8UOehcvJcyMOdj1m6A9lzC_d45Xi/view?usp=drive_link