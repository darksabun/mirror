ほしのねがい [Wish upon a Shooting Stars]

BPM:168 推定難易度:st7 NOTES:2497 TOTAL:477

キー音の追加あり

同梱譜面(hoshino_negai_DUMMY.b)と比較して追加したキー音以外のズレ抜け無し

本体URL(保管)
　→https://drive.google.com/file/d/1TdDDTPVmx_Ydx797h0EQNHTcCp0gXvPF/view?usp=drive_link