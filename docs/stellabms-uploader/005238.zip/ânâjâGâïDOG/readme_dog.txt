本体URL https://manbow.nothing.sh/event/event.cgi?action=More_def&num=3&event=120
Note : 2714
Total : 543 (2.0%)
275乱打+微縦、局所難。あとかわいい犬

バナーは勝手に作りました。

犬妖