(st2?) tinnitus [Intense]

本体URL:
https://onedrive.live.com/?cid=578814ACC2BD5A74&id=578814ACC2BD5A74%21140

魔女様の[HEARTFUL]差分のアレンジをベースに作成しています
元差分に同梱されている追加画像ファイルが無いとBGAが欠けるため、未所持の方はこちらも導入してください
(stella2900):
https://stellabms.xyz/upload/2900

ズレ抜けについて
	アレンジ差分のため本体同梱譜面とのズレチェック不可
	上記差分リンクの[HEARTFUL]([HEARTFUL].bms)とbms diff toolで比較して、ズレ抜け無し


