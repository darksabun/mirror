本体:https://manbow.nothing.sh/event/event.cgi?action=More_def&num=300&event=140
同梱SPA([v1.2 TOTAL値修正版 132091KB])と比較してズレ抜け無し