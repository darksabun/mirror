双ツ星 ～Prelude～ (7-M)
challenger / obj:Mary_Sue

本体：http://uploader.bms.ms/data/sen-goku/challenger/futatsuboshi.rar
推定レベル：★14

よろしくお願いします。

2025/12/27
Mary_Sue