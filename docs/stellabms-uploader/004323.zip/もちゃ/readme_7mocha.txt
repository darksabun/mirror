★★3/SB9? Burnt Mocha [もちゃ]

litmus* obj:EGRET.

同梱「litmus_burntmocha_04_7a.bms」と比較してズレ抜けなし

本体URL
https://manbow.nothing.sh/event/event.cgi?action=More_def&num=302&event=142