Polymorphism -首都高バトル-

BPM:138 推定難易度:st8～9 NOTES:2940 TOTAL:590

手動ディレイ等の意図的なキー音の追加あり

同梱未配置(polymorphism_tmp._bms)と比較して追加したキー音以外のズレ抜け無し

本体URL
　→http://manbow.nothing.sh/event/event.cgi?action=More_def&num=16&event=110