秋思に三日月　あなたに紅葉 [Ain't too proud to rely on!]

BPM:146 推定難易度:st9 NOTES:3488 TOTAL:768

意図的なキー音の追加あり

BMS diff toolで同梱譜面(_akimomi_a.bme)と比較してズレ抜け無し
AnzuBMSDifftoolで検出されるズレ抜けは意図的なソフラン削除によるものです

本体URL
　→https://drive.google.com/file/d/1VWfIgFZwZzjHWlxmQ1pJNMHFA_Ad7YoK/view?usp=drive_link