girl(BGA) -さきさのばし-
Toti bga:morigasigeru obj:Mary_Sue

本体：https://web.archive.org/web/20061208164450/http://he2ho2.s7.xrea.com/mori/toti_girl_bga.zip
推定レベル：★24

girl_bga_5key.bms基準ズレ抜けなし。
よろしくお願いいたします。

Mary_Sue (https://darksabun.github.io/Mary_Sue/ & @MarySue_BMS)
2024/09/08