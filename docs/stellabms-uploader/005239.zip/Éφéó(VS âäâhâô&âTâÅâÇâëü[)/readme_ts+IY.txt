戦い(VS ヤドン&サワムラー)

BPM:183 推定難易度:★★5 NOTES:1853 TOTAL:390

意図的なキー音の追加や削除を含むアレンジ差分

本体URL
　→https://drive.google.com/open?id=0B7qCw4hNijr4Q201VGE5dDdjdDQ