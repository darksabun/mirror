本体:https://venue.bmssearch.net/bmstukuru2025/34
同梱_7.bmsとズレ抜けなし