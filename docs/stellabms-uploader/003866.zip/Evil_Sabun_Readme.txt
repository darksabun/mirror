Evil Sanctions [BRUTAL EXORCISM]
くるやのぶ / OBJ : Mary_Sue BGA : 珊瑚

本体：https://9domu46i.com/yuruyuru/phase18.html
推定レベル：★21

Evil Sanctions_no_obj基準ズレ抜けなし。
よろしくお願いいたします。

Mary_Sue (https://darksabun.github.io/Mary_Sue/ or @MarySue_BMS)
2024/04/23