Title: evidence [Anti-Intellectualism]
BMS by Yusuke Takeuchi: https://web.archive.org/web/20120109085440/http://www.commonsense.nu/songs/evidence_hq.rar
Difficulty: FL5
BPM: 112
Comment:

It's a certain evidence.