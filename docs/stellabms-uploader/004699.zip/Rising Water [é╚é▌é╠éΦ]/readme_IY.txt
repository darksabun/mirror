Rising Water [なみのり]

BPM:153 乱打/微縦連　推定難易度: NOTES:2511 TOTAL:478

無音ノーツを使っています

同梱譜面(Rising Water[NORMAL].bme)と比較してズレ抜け無し

本体URL
　→https://web.archive.org/web/20160425024444/http://black-funeral.kill.jp/Rising_Water.zip