GREMLIN [HURTLESS]

BPM:230 推定難易度:st7 NOTES:3302 TOTAL:695

キー音の追加あり

同梱譜面(gremlin_normal.bms)と比較して追加したキー音以外のズレ抜け無し

本体URL
　→https://manbow.nothing.sh/event/event.cgi?action=More_def&num=382&event=133