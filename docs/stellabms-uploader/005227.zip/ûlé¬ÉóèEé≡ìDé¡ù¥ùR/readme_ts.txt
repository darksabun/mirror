本体:https://k-bms.com/party_pabat/party.jsp?board_num=25&num=29&order=reg&odtype=a
同梱spaとズレなし