本体:https://venue.bmssearch.net/kivotos/3
ディレイによるズレあり