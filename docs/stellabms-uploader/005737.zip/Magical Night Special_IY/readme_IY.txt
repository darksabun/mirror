Magical Night Special [あたたかいまほう] / [こころないまほう]

BPM:178 推定難易度:st3/st12 NOTES:3530/3950 TOTAL:742/830

[こころないまほう]は意図的なキー音の追加あり

同梱譜面(Normal.bms)と比較して追加したキー音以外のズレ抜け無し

本体URL
　→https://manbow.nothing.sh/event/event.cgi?action=More_def&num=413&event=146