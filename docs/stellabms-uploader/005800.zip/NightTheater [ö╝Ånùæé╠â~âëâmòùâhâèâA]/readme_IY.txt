NightTheater [半熟卵のミラノ風ドリア]

BPM:151 推定難易度:★★6 NOTES:3273 TOTAL:590

意図的なキー音の追加や削除を含む差分なのでズレ抜けチェック不可

本体URL
　→https://manbow.nothing.sh/event/event.cgi?action=More_def&event=133&num=18