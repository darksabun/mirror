花嵐、空に溶けて [Sakura]

https://manbow.nothing.sh/event/event.cgi?action=More_def&num=25&event=142

鍵盤のズレがありますが、これは意図されていました。 (KICKキー音をいくつかに分けるため)