I'M HERE NOW [UNLEASHED EMOTIONS]

BPM:141  推定難易度:st7 NOTES:2704 TOTAL:514

キー音の追加あり

同梱譜面(IM_HERE_NOW[SP ANOTHER].bms)と比較して追加したキー音以外のズレ抜け無し

本体URL
　→https://manbow.nothing.sh/event/event.cgi?action=More_def&num=186&event=123