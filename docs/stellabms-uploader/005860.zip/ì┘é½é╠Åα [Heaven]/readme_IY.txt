裁きの鐘 [Heaven]

BPM:160 推定難易度:★★2 NOTES:2950 TOTAL:561(0.19%/N)

微曲改変あり

本体URL
　→https://venue.bmssearch.net/bms-classic/4