本体URL
https://drive.google.com/drive/folders/1XqhkOcfL-e6l3o74V_kNblsuHW4F8ipw

#043-#057に無音ノート(0Z)あり
他cc_memo02.bmsとずれ抜けなし