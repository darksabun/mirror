st2? Disaster [Inevitable]
st7? Disaster [Destined Fate]

Cansol mov. Ssimille, obj:Stellaおばさん

ディレイ付加のためズレチェック不可。

本体URL
https://venue.bmssearch.net/genreshuffle4/36