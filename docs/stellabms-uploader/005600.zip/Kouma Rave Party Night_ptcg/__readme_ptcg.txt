(st0?)
Kouma Rave Party Night [Randa Party]

本体URL:
https://manbow.nothing.sh/event/event.cgi?action=More_def&num=13&event=102

ズレ抜けについて
	キー音の追加、並び替えなどのアレンジを行っているためズレチェック不可
	同梱[SP U.N.KNOWN](KRPN_UN.bms)をベースに作成しており、こちらとbms diff toolで比較して検出されるズレ抜けは全て意図的であることを確認済みです