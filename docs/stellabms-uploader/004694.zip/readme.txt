https://manbow.nothing.sh/event/event.cgi?action=More_def&num=145&event=146

同梱 _0notes.bms_ から作成, _another7, _insane7とズレ抜け無し
微縦, 皿複合, 難易度に影響しない程度のLN ★22前後
respect for ★22 Apollo -Mare Tranquillitatis-