同梱差分とのズレは意図したものです。
本体:https://manbow.nothing.sh/event/event.cgi?action=More_def&num=316&event=123