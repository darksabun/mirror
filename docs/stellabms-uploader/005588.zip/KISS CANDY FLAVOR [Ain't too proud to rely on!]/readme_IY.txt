KISS CANDY FLAVOR [Ain't too proud to rely on!]

BPM:146 推定難易度:st9 NOTES:3614 TOTAL:723

同梱譜面(kiss candy flaver_n.bms)と比較してズレ抜け無し

本体URL
　→https://manbow.nothing.sh/event/event.cgi?action=More_def&num=132&event=74