Nextreme Generation [Beyond Generations]

BPM:156 推定難易度:st7 NOTES:3824 TOTAL:804

同梱されているwavファイルも一緒に導入してください

キー音をカットして再配置しているのでズレ抜けチェック不可
一応同梱譜面(03_7A.bme)と比較して再配置したキー音以外のズレ抜けは無し

本体URL
　→https://manbow.nothing.sh/event/event.cgi?action=More_def&num=201&event=127