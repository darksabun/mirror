原曲URL
https://manbow.nothing.sh/event/event.cgi?action=More_def&num=392&event=140

想定難易度st4
notes : 3300
TOTAL値 : 693

ラブゴ化改造計画による強引な曲改変あり。
半分ぐらいはラブゴとほぼ同じ配置にしてます。
汚い乱打部分は私が配置したと考えて良いです。
24分の音が小さいのでそこは心のラブゴを鳴らしてください。

