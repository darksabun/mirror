★24? Unwelcome School (tettere- nekomix) [動いてないのに 動いてないのに あっついついついついついついよ]

ねこみりん feat.桃雛なの obj:え

「_00_nekomirin_unwelcome_default.bms」と比較してズレ抜け無し

本体URL
https://venue.bmssearch.net/kivotos/16