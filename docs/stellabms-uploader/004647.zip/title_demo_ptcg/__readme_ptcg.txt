(st4?) タイトル画面／デモのうた [STARROD]

本体URL:
https://drive.usercontent.google.com/download?id=1aWEUbBwPCUKzxNdqYL0DyojR2W0BiHPr&export=download&authuser=0

ズレ抜けについて
	意図的なキー音の追加があります
	同梱[HYPER](title_demo[7H].bms)とbms diff toolで比較して、ズレ抜け無し