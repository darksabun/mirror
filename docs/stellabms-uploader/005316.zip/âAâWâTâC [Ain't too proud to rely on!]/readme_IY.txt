アジサイ [Ain't too proud to rely on!]

BPM:212 推定難易度:st7 NOTES:3977 TOTAL:895

キー音の追加あり

同梱譜面(litmus_azisai_7_02n.bms)と比較して追加したキー音以外のズレ抜け無し

本体URL
　→https://manbow.nothing.sh/event/event.cgi?action=More_def&num=167&event=137