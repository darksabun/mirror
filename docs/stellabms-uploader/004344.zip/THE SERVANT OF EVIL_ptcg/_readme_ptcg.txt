(st3?) THE SERVANT OF EVIL [Destruction]

本体URL:https://mega.nz/folder/FNFDCQaT#wfv-iI4UuSIaGpP0oFZdtQ/file/cAlmwSIC

ズレ抜けについて
	元々のキー音を分解した追加音源と手動ディレイのためズレチェック不可。
	同梱[SP Trace](soe_spt.bms)をベースに作成しており、こちらとbms diff toolで比較すると抜けが1つ検出されますが、意図的です。