(st5?)
タナ・タナ [ガチ・オシ]

本体URL:
https://manbow.nothing.sh/event/event.cgi?action=More_def&num=17&event=147

ズレ抜けについて
	意図的なキー音の追加あり
	同梱[BEGINNER](_BEGINNER.bml)とbms diff toolで比較して、ズレ抜け無し