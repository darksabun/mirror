カウガールとおもちゃの拳銃 [Ain't too proud to rely on!]/SABUN/SABUUN

BPM:190/225/243 推定難易度:st5/st9/st11 NOTES:2369 TOTAL:451/474/498

同梱譜面(Another.bms)と比較してズレ抜け無し/SABUN SABUUNはBPM変更差分の為ズレ抜けチェック不可

本体URL
　→https://aiueoeiua.wixsite.com/aaaaofficial/mybms