奇跡的な音色が織り成すヘヴンリーな爽快感を体感せよ！
某ゲームのLNをBMSでもやって見たかっただけの譜面です。すみません。
一応ガチ押し練習にも使えるようにしてみました。おためしあれ～

JUGGLE_spa.bmsと比較してズレはありません。
本体 https://manbow.nothing.sh/event/event.cgi?action=More_def&num=482&event=110