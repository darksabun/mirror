純粋な乱打譜面、sl7～sl8くらい？
bms diff toolにてズレ無し確認済み。