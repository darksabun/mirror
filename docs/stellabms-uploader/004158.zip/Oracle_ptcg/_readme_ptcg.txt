Oracle [Intense]

本体:https://venue.bmssearch.net/freebattle/25

ズレ抜けについて
	アレンジによるキー音の追加あり
	同梱[ANOTHER](7k A.bms)とbms diff toolで比較して検出される全てのズレ抜けは、BGA改変による意図的なものです。