[本体URL]
https://manbow.nothing.sh/event/event.cgi?action=More_def&num=5&event=149

[ズレ抜け]
同梱__ChocoCo_tmp.bmsとズレ抜け無し

[NOTES / TOTAL]
1300 notes / 314 (0.242)

[雑記]
ジャリ、LN、皿、ソフラン
☆11