st3? LiVEMeTAL [Final Mission]
本体URL:https://manbow.nothing.sh/event/event.cgi?action=More_def&num=49&event=131

同梱[HYPER](__hyper.bms)とbms diff toolで比較して、ズレ抜けが無いことを確認しています。