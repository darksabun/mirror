y-Aria [Love the Jacks]

BPM:130 ガチ押し 推定難易度:st6 NOTES:3631 TOTAL:741

同梱譜面(ridia_y-aria_7n.bms)と比較してズレ抜け無し

本体URL
　→https://manbow.nothing.sh/event/event.cgi?action=More_def&num=22&event=145