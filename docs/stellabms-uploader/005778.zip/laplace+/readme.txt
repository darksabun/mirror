本体:https://bmssearch.net/bmses/zDqQuor3C037Xl
難易度:★★4？
total:420
ズレ:手動ディレイによるズレあり
