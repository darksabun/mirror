(st7?)
JKillMe [やばみ]

本体URL:
https://manbow.nothing.sh/event/event.cgi?action=More_def&num=252&event=140

ズレ抜けについて
	意図的なキー音の追加あり
	同梱[SP REVENGE](_JKillMe_SPL.bms)とbms diff toolで比較して、ズレ抜け無し