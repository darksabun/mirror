CYCLONE [EX]
Made by 0samil0 (twitter @0samil0)

Level : ��1?
Notes : 1757
Total : 400

Thanks to MINT for permission! (twitter @SODA_DENIM)
Special thanks : suna (twitter @bm_suna)
		 DK@  (twitter @Frozen_sat)

Feel free to contact me for some feedback!