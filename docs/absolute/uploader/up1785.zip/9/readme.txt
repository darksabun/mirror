���ȁ@IX -Atoropos-�@�@Yusuke�@Takeuchi��

ttp://cid-ec29adccad727122.office.live.com/self.aspx/%e5%85%ac%e9%96%8b/6yen/[BMS][%e6%88%a6%20[sen-goku]%20%e5%9c%8b][%e6%9d%b1%e5%8c%97%e5%9c%b0%e5%8c%ba][Yusuke%20Takeuchi][d%5E4n%5E4b][IX%20-Atoropos-].7z