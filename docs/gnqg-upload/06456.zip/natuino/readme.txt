曲本体イベントページDLリンク切れのため以下からお願いします。
https://dropbox.bms.ms/u/53751238/Ino_BOFU2016_Natsuino_OGG.zip